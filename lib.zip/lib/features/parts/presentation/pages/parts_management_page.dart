import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

class PartsManagementPage extends StatelessWidget {
  const PartsManagementPage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('إدارة قطع الغيار'),
      ),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          // قائمة قطع الغيار
          _buildPartsList(),
          
          // زر إضافة قطعة غيار جديدة
          ElevatedButton(
            onPressed: () => _showAddPartDialog(context),
            child: const Text('إضافة قطعة غيار جديدة'),
          ),
        ],
      ),
    );
  }

  Widget _buildPartsList() {
    return Card(
      child: ListView.builder(
        shrinkWrap: true,
        physics: const NeverScrollableScrollPhysics(),
        itemCount: 10, // سيتم استبداله بقائمة حقيقية
        itemBuilder: (context, index) {
          return ListTile(
            title: Text('قطعة غيار ${index + 1}'),
            subtitle: Text('الكمية المتوفرة: ${index * 5}'),
            trailing: IconButton(
              icon: const Icon(Icons.edit),
              onPressed: () => _showEditPartDialog(context, index),
            ),
          );
        },
      ),
    );
  }

  void _showAddPartDialog(BuildContext context) {
    // تنفيذ إضافة قطعة غيار جديدة
  }

  void _showEditPartDialog(BuildContext context, int index) {
    // تنفيذ تعديل قطعة غيار
  }
}