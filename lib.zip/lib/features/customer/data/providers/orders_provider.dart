import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart' hide Order;
import 'package:firebase_auth/firebase_auth.dart';
import '../models/order_model.dart';

class OrdersProvider with ChangeNotifier {
  final List<Order> _orders = [];
  bool _isLoading = false;
  String? _error;

  List<Order> get orders => [..._orders];
  bool get isLoading => _isLoading;
  String? get error => _error;

  Future<void> fetchOrders() async {
    _isLoading = true;
    _error = null;
    notifyListeners();

    try {
      final userId = FirebaseAuth.instance.currentUser?.uid;
      if (userId == null) {
        throw Exception('User not authenticated');
      }

      final snapshot = await FirebaseFirestore.instance
          .collection('orders')
          .where('userId', isEqualTo: userId)
          .orderBy('date', descending: true)
          .get();

      final fetchedOrders = snapshot.docs.map((doc) {
        final data = doc.data();
        return Order.fromJson({
          'id': doc.id,
          ...data,
        });
      }).toList();

      _orders.clear();
      _orders.addAll(fetchedOrders);
      _isLoading = false;
      notifyListeners();
    } catch (e) {
      _error = e.toString();
      _isLoading = false;
      notifyListeners();
    }
  }

  Future<void> cancelOrder(String orderId) async {
    _isLoading = true;
    notifyListeners();

    try {
      await FirebaseFirestore.instance
          .collection('orders')
          .doc(orderId)
          .update({'status': 'cancelled'});

      // Update the local order status
      final index = _orders.indexWhere((order) => order.id == orderId);
      if (index >= 0) {
        final updatedOrder = Order(
          id: _orders[index].id,
          date: _orders[index].date,
          status: 'cancelled',
          items: _orders[index].items,
          total: _orders[index].total,
          paymentMethod: _orders[index].paymentMethod,
          address: _orders[index].address,
          city: _orders[index].city,
        );
        _orders[index] = updatedOrder;
      }

      _isLoading = false;
      notifyListeners();
    } catch (e) {
      _error = e.toString();
      _isLoading = false;
      notifyListeners();
    }
  }

  Order? getOrderById(String orderId) {
    final index = _orders.indexWhere((order) => order.id == orderId);
    if (index >= 0) {
      return _orders[index];
    }
    return null;
  }
}
