import 'package:flutter/foundation.dart';

class OrderItem {
  final String id;
  final String name;
  final double price;
  final int quantity;
  final String? imageUrl;

  OrderItem({
    required this.id,
    required this.name,
    required this.price,
    required this.quantity,
    this.imageUrl,
  });

  factory OrderItem.fromJson(Map<String, dynamic> json) {
    return OrderItem(
      id: json['id'] as String,
      name: json['name'] as String,
      price: (json['price'] as num).toDouble(),
      quantity: json['quantity'] as int,
      imageUrl: json['imageUrl'] as String?,
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'name': name,
      'price': price,
      'quantity': quantity,
      'imageUrl': imageUrl,
    };
  }
}

class Order {
  final String id;
  final DateTime date;
  final String status;
  final List<OrderItem> items;
  final double total;
  final String? paymentMethod;
  final String address;
  final String city;

  Order({
    required this.id,
    required this.date,
    required this.status,
    required this.items,
    required this.total,
    this.paymentMethod,
    required this.address,
    required this.city,
  });

  factory Order.fromJson(Map<String, dynamic> json) {
    return Order(
      id: json['id'] as String,
      date: DateTime.parse(json['date'] as String),
      status: json['status'] as String,
      items: (json['items'] as List<dynamic>)
          .map((item) => OrderItem.fromJson(item as Map<String, dynamic>))
          .toList(),
      total: (json['total'] as num).toDouble(),
      paymentMethod: json['paymentMethod'] as String?,
      address: json['address'] as String,
      city: json['city'] as String,
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'date': date.toIso8601String(),
      'status': status,
      'items': items.map((item) => item.toJson()).toList(),
      'total': total,
      'paymentMethod': paymentMethod,
      'address': address,
      'city': city,
    };
  }

  @override
  bool operator ==(Object other) {
    if (identical(this, other)) return true;

    return other is Order &&
        other.id == id &&
        other.date.isAtSameMomentAs(date) &&
        other.status == status &&
        listEquals(other.items, items) &&
        other.total == total &&
        other.paymentMethod == paymentMethod &&
        other.address == address &&
        other.city == city;
  }

  @override
  int get hashCode {
    return id.hashCode ^
        date.hashCode ^
        status.hashCode ^
        items.hashCode ^
        total.hashCode ^
        paymentMethod.hashCode ^
        address.hashCode ^
        city.hashCode;
  }
}
