import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';
import 'package:faz3a_car/core/theme/app_theme.dart';
import 'package:faz3a_car/main.dart';

class CheckoutPage extends StatefulWidget {
  const CheckoutPage({super.key});

  @override
  State<CheckoutPage> createState() => _CheckoutPageState();
}

class _CheckoutPageState extends State<CheckoutPage> {
  final _formKey = GlobalKey<FormState>();
  final _nameController = TextEditingController();
  final _phoneController = TextEditingController();
  final _addressController = TextEditingController();
  final _cityController = TextEditingController();

  String _paymentMethod = 'cod'; // Default payment method: Cash on Delivery
  bool _isProcessing = false;

  @override
  void dispose() {
    _nameController.dispose();
    _phoneController.dispose();
    _addressController.dispose();
    _cityController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final cartProvider = Provider.of<CartProvider>(context);

    return Scaffold(
      appBar: AppBar(
        title: Text(
          'إتمام الطلب',
          style: GoogleFonts.tajawal(
            fontWeight: FontWeight.bold,
          ),
        ),
      ),
      body: cartProvider.items.isEmpty
          ? _buildEmptyCart()
          : _buildCheckoutForm(context, cartProvider),
    );
  }

  Widget _buildEmptyCart() {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Icon(
            Icons.shopping_cart_outlined,
            size: 100,
            color: Colors.grey[400],
          ),
          const SizedBox(height: 24),
          Text(
            'السلة فارغة',
            style: GoogleFonts.tajawal(
              fontSize: 24,
              fontWeight: FontWeight.bold,
            ),
          ),
          const SizedBox(height: 8),
          Text(
            'لا يمكن إتمام الطلب بدون منتجات',
            style: GoogleFonts.tajawal(
              fontSize: 16,
              color: Colors.grey[600],
            ),
          ),
          const SizedBox(height: 32),
          ElevatedButton(
            onPressed: () {
              Navigator.pop(context);
            },
            style: ElevatedButton.styleFrom(
              backgroundColor: AppTheme.primaryColor,
              foregroundColor: Colors.white,
              padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 12),
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(12),
              ),
            ),
            child: Text(
              'العودة إلى السلة',
              style: GoogleFonts.tajawal(
                fontWeight: FontWeight.bold,
                fontSize: 16,
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildCheckoutForm(BuildContext context, CartProvider cartProvider) {
    return Padding(
      padding: const EdgeInsets.all(16.0),
      child: Form(
        key: _formKey,
        child: ListView(
          children: [
            // Order summary
            _buildOrderSummary(context, cartProvider),

            const SizedBox(height: 24),

            // Shipping information
            _buildSectionTitle('معلومات الشحن'),
            _buildTextFormField(
              controller: _nameController,
              labelText: 'الاسم الكامل',
              icon: Icons.person_outline,
              validator: (value) {
                if (value == null || value.isEmpty) {
                  return 'الرجاء إدخال الاسم الكامل';
                }
                return null;
              },
            ),
            _buildTextFormField(
              controller: _phoneController,
              labelText: 'رقم الهاتف',
              icon: Icons.phone_outlined,
              keyboardType: TextInputType.phone,
              validator: (value) {
                if (value == null || value.isEmpty) {
                  return 'الرجاء إدخال رقم الهاتف';
                } else if (!RegExp(r'^\d{10}$').hasMatch(value)) {
                  return 'الرجاء إدخال رقم هاتف صحيح (10 أرقام)';
                }
                return null;
              },
            ),
            _buildTextFormField(
              controller: _addressController,
              labelText: 'العنوان',
              icon: Icons.location_on_outlined,
              validator: (value) {
                if (value == null || value.isEmpty) {
                  return 'الرجاء إدخال العنوان';
                }
                return null;
              },
            ),
            _buildTextFormField(
              controller: _cityController,
              labelText: 'المدينة',
              icon: Icons.location_city_outlined,
              validator: (value) {
                if (value == null || value.isEmpty) {
                  return 'الرجاء إدخال المدينة';
                }
                return null;
              },
            ),

            const SizedBox(height: 24),

            // Payment method
            _buildSectionTitle('طريقة الدفع'),
            _buildPaymentMethodSelection(),

            const SizedBox(height: 8),

            // Link to payment methods page
            Align(
              alignment: Alignment.centerLeft,
              child: TextButton.icon(
                onPressed: () {
                  Navigator.pushNamed(context, '/payment-methods');
                },
                icon: const Icon(
                  Icons.info_outline,
                  size: 18,
                ),
                label: Text(
                  'معلومات عن طرق الدفع',
                  style: GoogleFonts.tajawal(
                    fontSize: 14,
                  ),
                ),
                style: TextButton.styleFrom(
                  foregroundColor: AppTheme.primaryColor,
                ),
              ),
            ),

            const SizedBox(height: 24),

            // Place order button
            _isProcessing
                ? const Center(child: CircularProgressIndicator())
                : SizedBox(
                    width: double.infinity,
                    height: 50,
                    child: ElevatedButton(
                      onPressed: () => _placeOrder(context, cartProvider),
                      style: ElevatedButton.styleFrom(
                        backgroundColor: AppTheme.primaryColor,
                        foregroundColor: Colors.white,
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(12),
                        ),
                      ),
                      child: Text(
                        'تأكيد الطلب',
                        style: GoogleFonts.tajawal(
                          fontSize: 18,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                    ),
                  ),

            const SizedBox(height: 40),
          ],
        ),
      ),
    );
  }

  Widget _buildSectionTitle(String title) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 16),
      child: Text(
        title,
        style: GoogleFonts.tajawal(
          fontSize: 18,
          fontWeight: FontWeight.bold,
        ),
      ),
    );
  }

  Widget _buildTextFormField({
    required TextEditingController controller,
    required String labelText,
    required IconData icon,
    TextInputType? keyboardType,
    String? Function(String?)? validator,
  }) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 16),
      child: TextFormField(
        controller: controller,
        decoration: InputDecoration(
          labelText: labelText,
          labelStyle: GoogleFonts.tajawal(),
          prefixIcon: Icon(icon),
          border: OutlineInputBorder(
            borderRadius: BorderRadius.circular(12),
          ),
          focusedBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(12),
            borderSide: BorderSide(color: AppTheme.primaryColor, width: 2),
          ),
          contentPadding:
              const EdgeInsets.symmetric(horizontal: 16, vertical: 16),
        ),
        style: GoogleFonts.tajawal(),
        keyboardType: keyboardType,
        validator: validator,
      ),
    );
  }

  Widget _buildPaymentMethodSelection() {
    return Card(
      elevation: 0,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(12),
        side: BorderSide(color: Colors.grey.shade300),
      ),
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          children: [
            _buildPaymentOption(
              title: 'الدفع عند الاستلام',
              subtitle: 'الدفع نقدًا عند استلام الطلب',
              value: 'cod',
              icon: Icons.money,
            ),
            const Divider(),
            _buildPaymentOption(
              title: 'بطاقة ائتمانية',
              subtitle: 'الدفع باستخدام بطاقة ائتمانية',
              value: 'card',
              icon: Icons.credit_card,
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildPaymentOption({
    required String title,
    required String subtitle,
    required String value,
    required IconData icon,
  }) {
    return RadioListTile<String>(
      title: Text(
        title,
        style: GoogleFonts.tajawal(
          fontWeight: FontWeight.bold,
        ),
      ),
      subtitle: Text(
        subtitle,
        style: GoogleFonts.tajawal(
          fontSize: 12,
          color: Colors.grey[600],
        ),
      ),
      value: value,
      groupValue: _paymentMethod,
      onChanged: (newValue) {
        setState(() {
          _paymentMethod = newValue!;
        });
      },
      secondary: Icon(
        icon,
        color: AppTheme.primaryColor,
      ),
      activeColor: AppTheme.primaryColor,
      contentPadding: const EdgeInsets.symmetric(horizontal: 0, vertical: 8),
    );
  }

  Widget _buildOrderSummary(BuildContext context, CartProvider cartProvider) {
    return Card(
      elevation: 2,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(12),
      ),
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              'ملخص الطلب',
              style: GoogleFonts.tajawal(
                fontSize: 18,
                fontWeight: FontWeight.bold,
              ),
            ),
            const SizedBox(height: 16),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text(
                  'إجمالي المنتجات:',
                  style: GoogleFonts.tajawal(
                    color: Colors.grey[700],
                  ),
                ),
                Text(
                  '${cartProvider.total.toStringAsFixed(2)} ريال',
                  style: GoogleFonts.tajawal(
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ],
            ),
            const SizedBox(height: 8),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text(
                  'رسوم الشحن:',
                  style: GoogleFonts.tajawal(
                    color: Colors.grey[700],
                  ),
                ),
                Text(
                  '15.00 ريال',
                  style: GoogleFonts.tajawal(
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ],
            ),
            const SizedBox(height: 8),
            const Divider(),
            const SizedBox(height: 8),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text(
                  'الإجمالي:',
                  style: GoogleFonts.tajawal(
                    fontSize: 18,
                    fontWeight: FontWeight.bold,
                  ),
                ),
                Text(
                  '${(cartProvider.total + 15).toStringAsFixed(2)} ريال',
                  style: GoogleFonts.tajawal(
                    fontSize: 18,
                    fontWeight: FontWeight.bold,
                    color: AppTheme.primaryColor,
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }

  void _placeOrder(BuildContext context, CartProvider cartProvider) async {
    if (!_formKey.currentState!.validate()) {
      return;
    }

    setState(() {
      _isProcessing = true;
    });

    // Simulate order processing
    await Future.delayed(const Duration(seconds: 2));

    if (!mounted) return;

    setState(() {
      _isProcessing = false;
    });

    // Create order data
    final orderData = {
      'customerName': _nameController.text,
      'customerPhone': _phoneController.text,
      'customerAddress': _addressController.text,
      'customerCity': _cityController.text,
      'paymentMethod': _paymentMethod,
      'items': cartProvider.items,
      'subtotal': cartProvider.total,
      'shippingFee': 15.0,
      'total': cartProvider.total + 15.0,
      'orderDate': DateTime.now().toIso8601String(),
      'status': 'pending',
    };

    // Clear the cart
    cartProvider.clear();

    // Show success dialog
    _showOrderSuccessDialog(context);
  }

  void _showOrderSuccessDialog(BuildContext context) {
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (context) => AlertDialog(
        title: Row(
          children: [
            const Icon(
              Icons.check_circle,
              color: Colors.green,
              size: 30,
            ),
            const SizedBox(width: 8),
            Text(
              'تم تقديم الطلب بنجاح',
              style: GoogleFonts.tajawal(
                fontWeight: FontWeight.bold,
              ),
            ),
          ],
        ),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              'تم تقديم طلبك بنجاح وسيتم التواصل معك قريبًا لتأكيد الطلب.',
              style: GoogleFonts.tajawal(),
            ),
            const SizedBox(height: 16),
            Text(
              'يمكنك متابعة حالة طلبك من خلال صفحة "طلباتي".',
              style: GoogleFonts.tajawal(),
            ),
          ],
        ),
        actions: [
          TextButton(
            onPressed: () {
              Navigator.of(context).pop();
              Navigator.of(context).pushNamedAndRemoveUntil(
                '/home',
                (route) => false,
              );
            },
            child: Text(
              'العودة للرئيسية',
              style: GoogleFonts.tajawal(
                fontWeight: FontWeight.bold,
                color: AppTheme.primaryColor,
              ),
            ),
          ),
        ],
      ),
    );
  }
}
