import 'package:flutter/material.dart';
import 'package:faz3a_car/core/theme/app_theme.dart';
import 'package:provider/provider.dart';
import 'package:faz3a_car/main.dart';
import 'package:google_fonts/google_fonts.dart';

class WorkshopsPage extends StatefulWidget {
  const WorkshopsPage({super.key});

  @override
  State<WorkshopsPage> createState() => _WorkshopsPageState();
}

class _WorkshopsPageState extends State<WorkshopsPage>
    with SingleTickerProviderStateMixin {
  late TabController _tabController;
  String _searchQuery = '';
  final TextEditingController _searchController = TextEditingController();
  final List<Workshop> _workshops = [];
  bool _isLoading = true;

  @override
  void initState() {
    super.initState();
    _tabController = TabController(length: 4, vsync: this);
    _loadWorkshops();
  }

  @override
  void dispose() {
    _tabController.dispose();
    _searchController.dispose();
    super.dispose();
  }

  Future<void> _loadWorkshops() async {
    // Simulación de carga de datos
    await Future.delayed(const Duration(milliseconds: 1200));

    // Datos de ejemplo
    _workshops.addAll([
      Workshop(
        id: '1',
        name: 'ورشة المركز للميكانيكا',
        rating: 4.8,
        reviewCount: 136,
        specialty: 'ميكانيكا عامة',
        location: 'شارع الملك فهد، الرياض',
        phone: '0501234567',
        openHours: '8:00 ص - 9:00 م',
        services: ['صيانة المحرك', 'الفرامل', 'التكييف', 'التعليق'],
        imageUrl: 'https://via.placeholder.com/300x150?text=Workshop+1',
        distance: 2.5,
      ),
      Workshop(
        id: '2',
        name: 'ورشة الأمان للكهرباء',
        rating: 4.6,
        reviewCount: 98,
        specialty: 'كهرباء سيارات',
        location: 'شارع التخصصي، الرياض',
        phone: '0502345678',
        openHours: '9:00 ص - 10:00 م',
        services: ['إصلاح الكهرباء', 'البطاريات', 'المصابيح', 'أنظمة التشغيل'],
        imageUrl: 'https://via.placeholder.com/300x150?text=Workshop+2',
        distance: 3.2,
      ),
      Workshop(
        id: '3',
        name: 'ورشة النخبة للسيارات الفاخرة',
        rating: 4.9,
        reviewCount: 213,
        specialty: 'صيانة السيارات الفاخرة',
        location: 'شارع العليا، الرياض',
        phone: '0503456789',
        openHours: '9:00 ص - 11:00 م',
        services: [
          'برمجة كمبيوتر',
          'تشخيص أعطال',
          'صيانة شاملة',
          'قطع غيار أصلية'
        ],
        imageUrl: 'https://via.placeholder.com/300x150?text=Workshop+3',
        distance: 5.1,
      ),
      Workshop(
        id: '4',
        name: 'ورشة السرعة لصيانة السيارات',
        rating: 4.2,
        reviewCount: 75,
        specialty: 'ميكانيكا وكهرباء',
        location: 'شارع خالد بن الوليد، الرياض',
        phone: '0504567890',
        openHours: '8:00 ص - 8:00 م',
        services: ['إصلاح سريع', 'تغيير زيوت', 'بطاريات', 'إطارات'],
        imageUrl: 'https://via.placeholder.com/300x150?text=Workshop+4',
        distance: 1.8,
      ),
      Workshop(
        id: '5',
        name: 'مركز الفحص والصيانة الشاملة',
        rating: 4.7,
        reviewCount: 158,
        specialty: 'فحص شامل وصيانة',
        location: 'طريق الملك عبد العزيز، الرياض',
        phone: '0505678901',
        openHours: '7:30 ص - 10:00 م',
        services: ['فحص شامل', 'كشف أعطال', 'إصلاح', 'صيانة دورية'],
        imageUrl: 'https://via.placeholder.com/300x150?text=Workshop+5',
        distance: 4.3,
      ),
    ]);

    setState(() {
      _isLoading = false;
    });
  }

  @override
  Widget build(BuildContext context) {
    final themeProvider = Provider.of<ThemeProvider>(context);
    final isDarkMode = themeProvider.isDarkMode;

    return Scaffold(
      appBar: AppBar(
        title: Text(
          'ورش الصيانة',
          style: GoogleFonts.cairo(
            fontSize: 20,
            fontWeight: FontWeight.bold,
          ),
        ),
        actions: [
          IconButton(
            icon: Icon(
              isDarkMode ? Icons.wb_sunny : Icons.nightlight_round,
              color: AppTheme.primaryColor,
            ),
            onPressed: () => themeProvider.toggleTheme(),
            tooltip: isDarkMode ? 'الوضع المشمس' : 'الوضع الليلي',
          ),
        ],
        bottom: TabBar(
          controller: _tabController,
          indicatorColor: AppTheme.primaryColor,
          labelColor: AppTheme.primaryColor,
          unselectedLabelColor: isDarkMode ? Colors.white70 : Colors.black54,
          tabs: [
            Tab(text: 'الكل'),
            Tab(text: 'الميكانيكا'),
            Tab(text: 'الكهرباء'),
            Tab(text: 'المتخصصة'),
          ],
        ),
      ),
      body: Container(
        decoration: BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
            colors: isDarkMode
                ? [
                    AppTheme.darkBackgroundColor,
                    AppTheme.darkCardColor,
                  ]
                : [
                    AppTheme.lightBackgroundColor,
                    Colors.white,
                  ],
          ),
        ),
        child: Padding(
          padding: const EdgeInsets.all(16.0),
          child: Column(
            children: [
              Container(
                decoration: BoxDecoration(
                  color: isDarkMode ? AppTheme.darkCardColor : Colors.white,
                  borderRadius: BorderRadius.circular(12),
                  boxShadow: [
                    BoxShadow(
                      color: Colors.black.withOpacity(0.05),
                      blurRadius: 10,
                      offset: const Offset(0, 2),
                    ),
                  ],
                ),
                child: TextField(
                  controller: _searchController,
                  onChanged: (value) {
                    setState(() {
                      _searchQuery = value;
                    });
                  },
                  decoration: InputDecoration(
                    hintText: 'البحث عن ورش الصيانة...',
                    prefixIcon: const Icon(
                      Icons.search,
                      color: AppTheme.primaryColor,
                    ),
                    suffixIcon: _searchQuery.isNotEmpty
                        ? IconButton(
                            icon: const Icon(Icons.clear),
                            onPressed: () {
                              setState(() {
                                _searchQuery = '';
                                _searchController.clear();
                              });
                            },
                          )
                        : null,
                    border: InputBorder.none,
                    contentPadding: const EdgeInsets.symmetric(
                      horizontal: 16,
                      vertical: 12,
                    ),
                  ),
                ),
              ),
              const SizedBox(height: 16),
              Expanded(
                child: _isLoading
                    ? const Center(
                        child: CircularProgressIndicator(),
                      )
                    : TabBarView(
                        controller: _tabController,
                        children: [
                          _buildWorkshopList(null),
                          _buildWorkshopList('ميكانيكا'),
                          _buildWorkshopList('كهرباء'),
                          _buildWorkshopList('متخصصة'),
                        ],
                      ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildWorkshopList(String? specialty) {
    // Filtrar talleres según especialidad y búsqueda
    final filteredWorkshops = _workshops.where((workshop) {
      final matchesSpecialty = specialty == null ||
          workshop.specialty.toLowerCase().contains(specialty.toLowerCase());
      final matchesSearch = _searchQuery.isEmpty ||
          workshop.name.toLowerCase().contains(_searchQuery.toLowerCase()) ||
          workshop.specialty
              .toLowerCase()
              .contains(_searchQuery.toLowerCase()) ||
          workshop.location.toLowerCase().contains(_searchQuery.toLowerCase());
      return matchesSpecialty && matchesSearch;
    }).toList();

    if (filteredWorkshops.isEmpty) {
      return Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(
              Icons.search_off,
              size: 64,
              color: Colors.grey[400],
            ),
            const SizedBox(height: 16),
            Text(
              'لم يتم العثور على ورش صيانة',
              style: GoogleFonts.tajawal(
                fontSize: 18,
                color: Colors.grey[600],
              ),
            ),
          ],
        ),
      );
    }

    return ListView.builder(
      itemCount: filteredWorkshops.length,
      itemBuilder: (context, index) {
        final workshop = filteredWorkshops[index];
        return _buildWorkshopCard(workshop);
      },
    );
  }

  Widget _buildWorkshopCard(Workshop workshop) {
    final isDarkMode = Provider.of<ThemeProvider>(context).isDarkMode;

    return Container(
      margin: const EdgeInsets.only(bottom: 16),
      decoration: BoxDecoration(
        color: isDarkMode ? AppTheme.darkCardColor : Colors.white,
        borderRadius: BorderRadius.circular(16),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.05),
            blurRadius: 10,
            offset: const Offset(0, 2),
          ),
        ],
      ),
      child: ClipRRect(
        borderRadius: BorderRadius.circular(16),
        child: Column(
          children: [
            Image.network(
              workshop.imageUrl,
              height: 120,
              width: double.infinity,
              fit: BoxFit.cover,
              errorBuilder: (context, error, stackTrace) {
                return Container(
                  height: 120,
                  color: Colors.grey[300],
                  child: Icon(
                    Icons.image_not_supported,
                    color: Colors.grey,
                    size: 40,
                  ),
                );
              },
            ),
            Padding(
              padding: const EdgeInsets.all(16.0),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Expanded(
                        child: Text(
                          workshop.name,
                          style: GoogleFonts.cairo(
                            fontSize: 18,
                            fontWeight: FontWeight.bold,
                          ),
                          overflow: TextOverflow.ellipsis,
                        ),
                      ),
                      Container(
                        padding: const EdgeInsets.symmetric(
                          horizontal: 8,
                          vertical: 4,
                        ),
                        decoration: BoxDecoration(
                          color: AppTheme.primaryColor.withOpacity(0.1),
                          borderRadius: BorderRadius.circular(12),
                        ),
                        child: Row(
                          children: [
                            Icon(
                              Icons.star,
                              color: Colors.amber,
                              size: 16,
                            ),
                            const SizedBox(width: 4),
                            Text(
                              '${workshop.rating}',
                              style: const TextStyle(
                                fontWeight: FontWeight.bold,
                                fontSize: 14,
                              ),
                            ),
                            Text(
                              ' (${workshop.reviewCount})',
                              style: TextStyle(
                                color: isDarkMode
                                    ? Colors.white70
                                    : Colors.black54,
                                fontSize: 12,
                              ),
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 8),
                  Row(
                    children: [
                      Container(
                        padding: const EdgeInsets.symmetric(
                          horizontal: 8,
                          vertical: 4,
                        ),
                        decoration: BoxDecoration(
                          color: isDarkMode
                              ? Colors.blue.withOpacity(0.15)
                              : Colors.blue.withOpacity(0.1),
                          borderRadius: BorderRadius.circular(4),
                        ),
                        child: Text(
                          workshop.specialty,
                          style: const TextStyle(
                            color: Colors.blue,
                            fontSize: 12,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                      ),
                      const SizedBox(width: 8),
                      Icon(
                        Icons.location_on,
                        color: isDarkMode ? Colors.white70 : Colors.black54,
                        size: 16,
                      ),
                      const SizedBox(width: 4),
                      Expanded(
                        child: Text(
                          '${workshop.distance} كم - ${workshop.location}',
                          style: TextStyle(
                            color: isDarkMode ? Colors.white70 : Colors.black54,
                            fontSize: 14,
                          ),
                          overflow: TextOverflow.ellipsis,
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 12),
                  Text(
                    'الخدمات:',
                    style: GoogleFonts.cairo(
                      fontSize: 14,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                  const SizedBox(height: 4),
                  Wrap(
                    spacing: 8,
                    runSpacing: 8,
                    children: workshop.services.map((service) {
                      return Container(
                        padding: const EdgeInsets.symmetric(
                          horizontal: 8,
                          vertical: 4,
                        ),
                        decoration: BoxDecoration(
                          color: isDarkMode
                              ? AppTheme.primaryColor.withOpacity(0.15)
                              : AppTheme.primaryColor.withOpacity(0.1),
                          borderRadius: BorderRadius.circular(4),
                        ),
                        child: Text(
                          service,
                          style: TextStyle(
                            color: AppTheme.primaryColor,
                            fontSize: 12,
                          ),
                        ),
                      );
                    }).toList(),
                  ),
                  const SizedBox(height: 12),
                  Row(
                    children: [
                      Icon(
                        Icons.access_time,
                        color: isDarkMode ? Colors.white70 : Colors.black54,
                        size: 16,
                      ),
                      const SizedBox(width: 4),
                      Text(
                        workshop.openHours,
                        style: TextStyle(
                          color: isDarkMode ? Colors.white70 : Colors.black54,
                          fontSize: 14,
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 16),
                  Row(
                    children: [
                      Expanded(
                        child: ElevatedButton.icon(
                          onPressed: () {
                            // Implementar llamada
                          },
                          icon: const Icon(Icons.phone),
                          label: const Text('اتصال'),
                          style: ElevatedButton.styleFrom(
                            backgroundColor: AppTheme.primaryColor,
                            foregroundColor: Colors.white,
                            padding: const EdgeInsets.symmetric(vertical: 12),
                          ),
                        ),
                      ),
                      const SizedBox(width: 12),
                      Expanded(
                        child: OutlinedButton.icon(
                          onPressed: () {
                            // Implementar chat
                          },
                          icon: const Icon(Icons.chat_bubble_outline),
                          label: const Text('مراسلة'),
                          style: OutlinedButton.styleFrom(
                            foregroundColor: AppTheme.primaryColor,
                            side:
                                const BorderSide(color: AppTheme.primaryColor),
                            padding: const EdgeInsets.symmetric(vertical: 12),
                          ),
                        ),
                      ),
                    ],
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class Workshop {
  final String id;
  final String name;
  final double rating;
  final int reviewCount;
  final String specialty;
  final String location;
  final String phone;
  final String openHours;
  final List<String> services;
  final String imageUrl;
  final double distance;

  Workshop({
    required this.id,
    required this.name,
    required this.rating,
    required this.reviewCount,
    required this.specialty,
    required this.location,
    required this.phone,
    required this.openHours,
    required this.services,
    required this.imageUrl,
    required this.distance,
  });
}
