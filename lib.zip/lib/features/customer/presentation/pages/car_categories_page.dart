import 'package:flutter/material.dart';
import 'package:faz3a_car/core/theme/app_theme.dart';
import 'package:provider/provider.dart';
import 'package:faz3a_car/main.dart';
import 'package:google_fonts/google_fonts.dart';

class CarCategoriesPage extends StatelessWidget {
  const CarCategoriesPage({super.key});

  @override
  Widget build(BuildContext context) {
    final themeProvider = Provider.of<ThemeProvider>(context);
    final isDarkMode = themeProvider.isDarkMode;

    return Scaffold(
      appBar: AppBar(
        title: Text(
          'فئات السيارات',
          style: GoogleFonts.cairo(
            fontSize: 20,
            fontWeight: FontWeight.bold,
          ),
        ),
        actions: [
          IconButton(
            icon: Icon(
              isDarkMode ? Icons.wb_sunny : Icons.nightlight_round,
              color: AppTheme.primaryColor,
            ),
            onPressed: () => themeProvider.toggleTheme(),
            tooltip: isDarkMode ? 'الوضع المشمس' : 'الوضع الليلي',
          ),
        ],
      ),
      body: Container(
        decoration: BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
            colors: isDarkMode
                ? [
                    AppTheme.darkBackgroundColor,
                    AppTheme.darkCardColor,
                  ]
                : [
                    AppTheme.lightBackgroundColor,
                    Colors.white,
                  ],
          ),
        ),
        child: Padding(
          padding: const EdgeInsets.all(16.0),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                'اختر فئة السيارة',
                style: GoogleFonts.cairo(
                  fontSize: 24,
                  fontWeight: FontWeight.bold,
                ),
              ),
              const SizedBox(height: 8),
              Text(
                'ابحث عن قطع الغيار حسب مكونات السيارة',
                style: GoogleFonts.tajawal(
                  fontSize: 16,
                  color: isDarkMode ? Colors.white70 : Colors.black54,
                ),
              ),
              const SizedBox(height: 24),
              Expanded(
                child: GridView.count(
                  crossAxisCount: 2,
                  crossAxisSpacing: 16,
                  mainAxisSpacing: 16,
                  children: [
                    _buildCategoryCard(
                      context,
                      'المحرك',
                      Icons.precision_manufacturing,
                      Colors.red.shade600,
                      'محرك',
                    ),
                    _buildCategoryCard(
                      context,
                      'الفرامل',
                      Icons.speed,
                      Colors.blue.shade600,
                      'فرامل',
                    ),
                    _buildCategoryCard(
                      context,
                      'نظام التوجيه',
                      Icons.airline_seat_recline_normal,
                      Colors.green.shade600,
                      'توجيه',
                    ),
                    _buildCategoryCard(
                      context,
                      'نظام التعليق',
                      Icons.line_weight,
                      Colors.purple.shade600,
                      'تعليق',
                    ),
                    _buildCategoryCard(
                      context,
                      'النظام الكهربائي',
                      Icons.flash_on,
                      Colors.amber.shade600,
                      'كهرباء',
                    ),
                    _buildCategoryCard(
                      context,
                      'نظام الوقود',
                      Icons.local_gas_station,
                      Colors.orange.shade600,
                      'وقود',
                    ),
                    _buildCategoryCard(
                      context,
                      'التبريد والتكييف',
                      Icons.ac_unit,
                      Colors.indigo.shade600,
                      'تبريد',
                    ),
                    _buildCategoryCard(
                      context,
                      'إطارات وعجلات',
                      Icons.tire_repair,
                      Colors.teal.shade600,
                      'إطارات',
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
      bottomNavigationBar: Container(
        padding: const EdgeInsets.all(16),
        decoration: BoxDecoration(
          color: isDarkMode ? AppTheme.darkCardColor : Colors.white,
          boxShadow: [
            BoxShadow(
              color: Colors.black.withOpacity(0.05),
              blurRadius: 10,
              offset: const Offset(0, -5),
            ),
          ],
        ),
        child: ElevatedButton(
          onPressed: () {
            Navigator.pushNamed(context, '/workshops');
          },
          style: ElevatedButton.styleFrom(
            backgroundColor: AppTheme.primaryColor,
            padding: const EdgeInsets.symmetric(vertical: 15),
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(12),
            ),
          ),
          child: Text(
            'البحث عن ورش الصيانة',
            style: GoogleFonts.cairo(
              fontSize: 16,
              fontWeight: FontWeight.bold,
              color: Colors.white,
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildCategoryCard(
    BuildContext context,
    String title,
    IconData icon,
    Color color,
    String categoryKey,
  ) {
    final isDarkMode = Provider.of<ThemeProvider>(context).isDarkMode;

    return GestureDetector(
      onTap: () {
        Navigator.pushNamed(
          context,
          '/category-parts',
          arguments: {
            'category': title,
            'categoryKey': categoryKey,
          },
        );
      },
      child: Container(
        decoration: BoxDecoration(
          color: isDarkMode ? AppTheme.darkCardColor : Colors.white,
          borderRadius: BorderRadius.circular(16),
          boxShadow: [
            BoxShadow(
              color: Colors.black.withOpacity(0.05),
              blurRadius: 10,
              offset: const Offset(0, 2),
            ),
          ],
        ),
        child: Stack(
          children: [
            Positioned(
              right: -15,
              top: -15,
              child: Container(
                height: 80,
                width: 80,
                decoration: BoxDecoration(
                  color: color.withOpacity(0.1),
                  shape: BoxShape.circle,
                ),
              ),
            ),
            Padding(
              padding: const EdgeInsets.all(16.0),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Container(
                    padding: const EdgeInsets.all(12),
                    decoration: BoxDecoration(
                      color: color.withOpacity(0.1),
                      borderRadius: BorderRadius.circular(12),
                    ),
                    child: Icon(
                      icon,
                      color: color,
                      size: 28,
                    ),
                  ),
                  const Spacer(),
                  Text(
                    title,
                    style: GoogleFonts.cairo(
                      fontSize: 16,
                      fontWeight: FontWeight.bold,
                    ),
                    maxLines: 2,
                    overflow: TextOverflow.ellipsis,
                  ),
                  const SizedBox(height: 8),
                  Row(
                    children: [
                      Text(
                        'عرض القطع',
                        style: GoogleFonts.tajawal(
                          fontSize: 14,
                          color: color,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                      const SizedBox(width: 4),
                      Icon(
                        Icons.arrow_forward,
                        size: 16,
                        color: color,
                      ),
                    ],
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}
