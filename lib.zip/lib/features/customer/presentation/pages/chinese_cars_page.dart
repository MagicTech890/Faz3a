import 'package:flutter/material.dart';
import 'package:faz3a_car/core/theme/app_theme.dart';
import 'package:provider/provider.dart';
import 'package:faz3a_car/main.dart';
import 'package:google_fonts/google_fonts.dart';

class ChineseCarsPage extends StatefulWidget {
  const ChineseCarsPage({super.key});

  @override
  State<ChineseCarsPage> createState() => _ChineseCarsPageState();
}

class _ChineseCarsPageState extends State<ChineseCarsPage> {
  String _searchQuery = '';
  final TextEditingController _searchController = TextEditingController();
  String _selectedBrand = 'الكل';

  final List<String> chineseBrands = [
    'الكل',
    'شيري - Chery',
    'جيلي - Geely',
    'هافال - Haval',
    'شانجان - Changan',
    'بايك - BAIC',
    'جريت وول - Great Wall',
    'MG',
    'BYD',
    'دونغفينغ - Dongfeng',
    'زوتي - Zotye',
    'JAC',
    'أخرى',
  ];

  @override
  void dispose() {
    _searchController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final themeProvider = Provider.of<ThemeProvider>(context);
    final isDarkMode = themeProvider.isDarkMode;

    return Scaffold(
      appBar: AppBar(
        title: Text(
          'السيارات الصينية',
          style: GoogleFonts.cairo(
            fontSize: 20,
            fontWeight: FontWeight.bold,
          ),
        ),
        actions: [
          IconButton(
            icon: Icon(
              isDarkMode ? Icons.wb_sunny : Icons.nightlight_round,
              color: AppTheme.primaryColor,
            ),
            onPressed: () => themeProvider.toggleTheme(),
            tooltip: isDarkMode ? 'الوضع المشمس' : 'الوضع الليلي',
          ),
        ],
      ),
      body: Container(
        decoration: BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
            colors: isDarkMode
                ? [
                    AppTheme.darkBackgroundColor,
                    AppTheme.darkCardColor,
                  ]
                : [
                    AppTheme.lightBackgroundColor,
                    Colors.white,
                  ],
          ),
        ),
        child: Padding(
          padding: const EdgeInsets.all(16.0),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              // Search bar
              Container(
                decoration: BoxDecoration(
                  color: isDarkMode ? AppTheme.darkCardColor : Colors.white,
                  borderRadius: BorderRadius.circular(12),
                  boxShadow: [
                    BoxShadow(
                      color: Colors.black.withOpacity(0.05),
                      blurRadius: 10,
                      offset: const Offset(0, 2),
                    ),
                  ],
                ),
                child: TextField(
                  controller: _searchController,
                  onChanged: (value) {
                    setState(() {
                      _searchQuery = value;
                    });
                  },
                  decoration: InputDecoration(
                    hintText: 'ابحث عن سيارة أو قطعة غيار...',
                    prefixIcon: const Icon(
                      Icons.search,
                      color: AppTheme.primaryColor,
                    ),
                    suffixIcon: _searchQuery.isNotEmpty
                        ? IconButton(
                            icon: const Icon(Icons.clear),
                            onPressed: () {
                              setState(() {
                                _searchQuery = '';
                                _searchController.clear();
                              });
                            },
                          )
                        : null,
                    border: InputBorder.none,
                    contentPadding: const EdgeInsets.symmetric(
                      horizontal: 16,
                      vertical: 12,
                    ),
                  ),
                ),
              ),
              const SizedBox(height: 24),

              Text(
                'ماركات السيارات الصينية',
                style: GoogleFonts.cairo(
                  fontSize: 20,
                  fontWeight: FontWeight.bold,
                ),
              ),
              const SizedBox(height: 16),

              // Brands horizontal list
              SizedBox(
                height: 40,
                child: ListView.builder(
                  scrollDirection: Axis.horizontal,
                  itemCount: chineseBrands.length,
                  itemBuilder: (context, index) {
                    final brand = chineseBrands[index];
                    final isSelected = _selectedBrand == brand;
                    return Padding(
                      padding: const EdgeInsets.only(right: 8),
                      child: GestureDetector(
                        onTap: () {
                          setState(() {
                            _selectedBrand = brand;
                          });
                        },
                        child: Container(
                          padding: const EdgeInsets.symmetric(
                            horizontal: 16,
                            vertical: 8,
                          ),
                          decoration: BoxDecoration(
                            color: isSelected
                                ? AppTheme.primaryColor
                                : isDarkMode
                                    ? AppTheme.darkCardColor
                                    : Colors.white,
                            borderRadius: BorderRadius.circular(20),
                            boxShadow: [
                              BoxShadow(
                                color: Colors.black.withOpacity(0.05),
                                blurRadius: 5,
                                offset: const Offset(0, 2),
                              ),
                            ],
                          ),
                          child: Text(
                            brand,
                            style: TextStyle(
                              color: isSelected
                                  ? Colors.white
                                  : isDarkMode
                                      ? Colors.white70
                                      : Colors.black87,
                              fontWeight: isSelected
                                  ? FontWeight.bold
                                  : FontWeight.normal,
                            ),
                          ),
                        ),
                      ),
                    );
                  },
                ),
              ),

              const SizedBox(height: 24),

              Expanded(
                child: _selectedBrand == 'الكل'
                    ? _buildAllBrandsGrid()
                    : _buildBrandDetails(),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildAllBrandsGrid() {
    return GridView.builder(
      gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
        crossAxisCount: 2,
        crossAxisSpacing: 16,
        mainAxisSpacing: 16,
        childAspectRatio: 1.1,
      ),
      itemCount: chineseBrands.length - 1, // Excluding "All"
      itemBuilder: (context, index) {
        final brand = chineseBrands[index + 1]; // Skip "All"
        return _buildBrandCard(brand);
      },
    );
  }

  Widget _buildBrandCard(String brand) {
    final isDarkMode = Provider.of<ThemeProvider>(context).isDarkMode;
    final colors = [
      Colors.red.shade600,
      Colors.blue.shade600,
      Colors.green.shade600,
      Colors.purple.shade600,
      Colors.orange.shade600,
      Colors.teal.shade600,
      Colors.indigo.shade600,
      Colors.amber.shade600,
      Colors.pink.shade600,
      Colors.deepPurple.shade600,
      Colors.cyan.shade600,
      Colors.brown.shade600,
    ];

    final brandIndex = chineseBrands.indexOf(brand) - 1;
    final color = colors[brandIndex % colors.length];

    // Get brand logo name (first part before the dash)
    String logoName = brand;
    if (brand.contains('-')) {
      logoName = brand.split('-')[0].trim();
    } else if (brand == 'أخرى') {
      logoName = 'أخرى';
    }

    return GestureDetector(
      onTap: () {
        setState(() {
          _selectedBrand = brand;
        });
      },
      child: Container(
        decoration: BoxDecoration(
          color: isDarkMode ? AppTheme.darkCardColor : Colors.white,
          borderRadius: BorderRadius.circular(16),
          boxShadow: [
            BoxShadow(
              color: Colors.black.withOpacity(0.05),
              blurRadius: 10,
              offset: const Offset(0, 2),
            ),
          ],
        ),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Container(
              padding: const EdgeInsets.all(16),
              decoration: BoxDecoration(
                color: color.withOpacity(0.1),
                shape: BoxShape.circle,
              ),
              child: Icon(
                Icons.directions_car,
                size: 40,
                color: color,
              ),
            ),
            const SizedBox(height: 12),
            Text(
              logoName,
              style: GoogleFonts.cairo(
                fontSize: 18,
                fontWeight: FontWeight.bold,
              ),
              textAlign: TextAlign.center,
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildBrandDetails() {
    // Filter cars models by selected brand and search query
    final filteredModels = getCarModels(_selectedBrand)
        .where((model) =>
            _searchQuery.isEmpty ||
            model.name.toLowerCase().contains(_searchQuery.toLowerCase()) ||
            model.description
                .toLowerCase()
                .contains(_searchQuery.toLowerCase()))
        .toList();

    if (filteredModels.isEmpty) {
      return Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(
              Icons.search_off,
              size: 64,
              color: Colors.grey[400],
            ),
            const SizedBox(height: 16),
            Text(
              'لم يتم العثور على موديلات',
              style: GoogleFonts.tajawal(
                fontSize: 18,
                color: Colors.grey[600],
              ),
            ),
          ],
        ),
      );
    }

    return ListView.builder(
      itemCount: filteredModels.length,
      itemBuilder: (context, index) {
        final model = filteredModels[index];
        return _buildCarModelCard(model);
      },
    );
  }

  Widget _buildCarModelCard(CarModel model) {
    final isDarkMode = Provider.of<ThemeProvider>(context).isDarkMode;

    return Container(
      margin: const EdgeInsets.only(bottom: 16),
      decoration: BoxDecoration(
        color: isDarkMode ? AppTheme.darkCardColor : Colors.white,
        borderRadius: BorderRadius.circular(16),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.05),
            blurRadius: 10,
            offset: const Offset(0, 2),
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          ClipRRect(
            borderRadius: const BorderRadius.only(
              topLeft: Radius.circular(16),
              topRight: Radius.circular(16),
            ),
            child: Image.network(
              model.imageUrl,
              height: 200,
              width: double.infinity,
              fit: BoxFit.cover,
              errorBuilder: (context, error, stackTrace) => Container(
                height: 200,
                color: Colors.grey[300],
                child: const Icon(
                  Icons.image_not_supported,
                  color: Colors.grey,
                  size: 64,
                ),
              ),
            ),
          ),
          Padding(
            padding: const EdgeInsets.all(16),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Text(
                      model.name,
                      style: GoogleFonts.cairo(
                        fontSize: 20,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                    Container(
                      padding: const EdgeInsets.symmetric(
                        horizontal: 12,
                        vertical: 6,
                      ),
                      decoration: BoxDecoration(
                        color: AppTheme.primaryColor.withOpacity(0.1),
                        borderRadius: BorderRadius.circular(12),
                      ),
                      child: Text(
                        model.year,
                        style: GoogleFonts.cairo(
                          color: AppTheme.primaryColor,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 8),
                Text(
                  model.description,
                  style: GoogleFonts.tajawal(
                    fontSize: 14,
                    color: isDarkMode ? Colors.white70 : Colors.black87,
                  ),
                ),
                const SizedBox(height: 16),
                const Divider(),
                const SizedBox(height: 8),
                Text(
                  'قطع الغيار الشائعة:',
                  style: GoogleFonts.cairo(
                    fontSize: 16,
                    fontWeight: FontWeight.bold,
                  ),
                ),
                const SizedBox(height: 8),
                Wrap(
                  spacing: 8,
                  runSpacing: 8,
                  children: model.commonParts.map((part) {
                    return Container(
                      padding: const EdgeInsets.symmetric(
                        horizontal: 12,
                        vertical: 6,
                      ),
                      decoration: BoxDecoration(
                        color: isDarkMode ? Colors.grey[800] : Colors.grey[200],
                        borderRadius: BorderRadius.circular(16),
                      ),
                      child: Text(
                        part,
                        style: GoogleFonts.tajawal(
                          fontSize: 14,
                          color: isDarkMode ? Colors.white70 : Colors.black87,
                        ),
                      ),
                    );
                  }).toList(),
                ),
                const SizedBox(height: 16),
                ElevatedButton.icon(
                  onPressed: () {
                    // Navigate to parts for this model
                    Navigator.pushNamed(
                      context,
                      '/category-parts',
                      arguments: {
                        'category': model.name,
                        'categoryKey': 'chinese-car-parts',
                      },
                    );
                  },
                  style: ElevatedButton.styleFrom(
                    backgroundColor: AppTheme.primaryColor,
                    foregroundColor: Colors.white,
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(8),
                    ),
                    padding: const EdgeInsets.symmetric(
                      horizontal: 16,
                      vertical: 12,
                    ),
                  ),
                  icon: const Icon(Icons.build),
                  label: Text(
                    'عرض قطع الغيار',
                    style: GoogleFonts.cairo(
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  // Helper method to get car models for a specific brand
  List<CarModel> getCarModels(String brand) {
    switch (brand) {
      case 'شيري - Chery':
        return [
          CarModel(
            name: 'شيري تيجو 7',
            year: '2022',
            description:
                'كروس أوفر بمحرك 1.5 لتر توربو، تتميز بتصميم عصري وتجهيزات حديثة.',
            imageUrl:
                'https://upload.wikimedia.org/wikipedia/commons/thumb/2/26/Chery_Tiggo_7_01_China_2018-03-07.jpg/1200px-Chery_Tiggo_7_01_China_2018-03-07.jpg',
            commonParts: [
              'فلتر زيت',
              'فلتر هواء',
              'شمعات إشعال',
              'مساعدات أمامية',
              'ديسكات فرامل'
            ],
          ),
          CarModel(
            name: 'شيري أريزو 5',
            year: '2021',
            description:
                'سيدان عائلية اقتصادية، تأتي بمحرك 1.5 لتر ونظام تعليق مريح.',
            imageUrl:
                'https://upload.wikimedia.org/wikipedia/commons/5/54/Chery_Arrizo_5_01_China_2016-04-16.jpg',
            commonParts: ['بطارية', 'فلتر مكيف', 'مساعدات خلفية', 'طقم دبرياج'],
          ),
        ];
      case 'جيلي - Geely':
        return [
          CarModel(
            name: 'جيلي أوكافانغو',
            year: '2023',
            description:
                'كروس أوفر عائلية فاخرة بسبعة مقاعد ومحرك تربو 1.8 لتر.',
            imageUrl:
                'https://upload.wikimedia.org/wikipedia/commons/thumb/c/c3/Geely_Okavango_1.5_TD_Urban_%28front%29.jpg/1200px-Geely_Okavango_1.5_TD_Urban_%28front%29.jpg',
            commonParts: [
              'طقم سيور',
              'فلتر زيت',
              'لمبات LED أمامية',
              'طقم فرامل'
            ],
          ),
          CarModel(
            name: 'جيلي كولراي',
            year: '2022',
            description:
                'كروس أوفر مدمجة بمحرك 1.5 لتر توربو وتقنيات متطورة للسلامة.',
            imageUrl:
                'https://upload.wikimedia.org/wikipedia/commons/thumb/9/96/Geely_Coolray_%28front%29.jpg/1200px-Geely_Coolray_%28front%29.jpg',
            commonParts: [
              'بوجيهات',
              'فلتر هواء',
              'زيت محرك خاص',
              'مساعدات أمامية'
            ],
          ),
        ];
      case 'هافال - Haval':
        return [
          CarModel(
            name: 'هافال H6',
            year: '2023',
            description:
                'كروس أوفر متوسطة الحجم بمحرك 1.5 لتر توربو وتصميم رياضي.',
            imageUrl:
                'https://upload.wikimedia.org/wikipedia/commons/thumb/5/5e/Haval_H6_%28China%29_front_view.jpg/1200px-Haval_H6_%28China%29_front_view.jpg',
            commonParts: [
              'فلتر بنزين',
              'حساس أكسجين',
              'ديسكات فرامل',
              'شمعات إشعال'
            ],
          ),
          CarModel(
            name: 'هافال جوليان',
            year: '2022',
            description:
                'كروس أوفر كوبيه بمحرك 2.0 لتر توربو، بتصميم عصري وتجهيزات فاخرة.',
            imageUrl:
                'https://upload.wikimedia.org/wikipedia/commons/d/da/Haval_Jolion_%28front%29.jpg',
            commonParts: ['طقم سيور', 'فلتر مكيف', 'عفشة', 'بطارية'],
          ),
        ];
      case 'شانجان - Changan':
        return [
          CarModel(
            name: 'شانجان CS75 بلس',
            year: '2023',
            description:
                'كروس أوفر متوسطة الحجم بمحرك 1.8 لتر توربو وتقنيات سلامة متقدمة.',
            imageUrl:
                'https://upload.wikimedia.org/wikipedia/commons/thumb/a/a2/Changan_CS75_PLUS_01_China_2020-03-09.jpg/1200px-Changan_CS75_PLUS_01_China_2020-03-09.jpg',
            commonParts: [
              'فلتر هواء',
              'لمبات إضاءة',
              'طقم فرامل',
              'مساعدات خلفية'
            ],
          ),
          CarModel(
            name: 'شانجان إيدو بلس',
            year: '2022',
            description:
                'سيدان مدمجة بمحرك 1.6 لتر، تتميز بالاقتصاد في استهلاك الوقود.',
            imageUrl:
                'https://upload.wikimedia.org/wikipedia/commons/thumb/e/ef/Changan_Eado_II_China_2018-04-07.jpg/1200px-Changan_Eado_II_China_2018-04-07.jpg',
            commonParts: ['فلتر زيت', 'مساعدات أمامية', 'بطارية', 'طقم دبرياج'],
          ),
        ];
      case 'MG':
        return [
          CarModel(
            name: 'MG ZS',
            year: '2023',
            description:
                'كروس أوفر مدمجة بمحرك 1.5 لتر، بتصميم عصري وسعر منافس.',
            imageUrl:
                'https://upload.wikimedia.org/wikipedia/commons/thumb/2/2a/MG_ZS_1.5L_Deluxe_2018_%2820190628%29.jpg/1200px-MG_ZS_1.5L_Deluxe_2018_%2820190628%29.jpg',
            commonParts: [
              'فلتر بنزين',
              'فلتر زيت',
              'بوجيهات',
              'مساعدات أمامية'
            ],
          ),
          CarModel(
            name: 'MG 5',
            year: '2022',
            description:
                'سيدان عصرية بمحرك 1.5 لتر، اقتصادية وعملية للاستخدام اليومي.',
            imageUrl:
                'https://upload.wikimedia.org/wikipedia/commons/thumb/d/d0/MG_5_08_China_2012-06-02.JPG/1200px-MG_5_08_China_2012-06-02.JPG',
            commonParts: ['حساس حرارة', 'طقم سيور', 'فلتر مكيف', 'دينمو'],
          ),
        ];
      // Add more cases for other brands
      case 'أخرى':
        return [
          CarModel(
            name: 'جاك J7',
            year: '2022',
            description:
                'سيدان متوسطة الحجم بمحرك 1.5 لتر توربو، تجمع بين الأداء والاقتصاد.',
            imageUrl:
                'https://img.jagranjosh.com/images/2021/November/11112021/JAC_J7_Sedan.jpg',
            commonParts: [
              'فلتر زيت',
              'أذرعة مساحات',
              'مساعدات خلفية',
              'لمبات LED'
            ],
          ),
          CarModel(
            name: 'فوتون سافانا',
            year: '2023',
            description:
                'بيك أب قوية بمحرك 2.4 لتر، مناسبة للاستخدامات التجارية والشخصية.',
            imageUrl:
                'https://img.jagranjosh.com/images/2022/July/2172022/Foton_Tunland_G7.jpg',
            commonParts: [
              'فلتر ديزل',
              'طقم دبرياج',
              'كراسي محرك',
              'عفشة مقوية'
            ],
          ),
        ];
      default:
        return [];
    }
  }
}

// Model class for car details
class CarModel {
  final String name;
  final String year;
  final String description;
  final String imageUrl;
  final List<String> commonParts;

  CarModel({
    required this.name,
    required this.year,
    required this.description,
    required this.imageUrl,
    required this.commonParts,
  });
}
