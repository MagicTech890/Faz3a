import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';
import 'package:faz3a_car/core/theme/app_theme.dart';
import 'package:faz3a_car/main.dart';

class CategoryPartsPage extends StatefulWidget {
  const CategoryPartsPage({super.key});

  @override
  State<CategoryPartsPage> createState() => _CategoryPartsPageState();
}

class _CategoryPartsPageState extends State<CategoryPartsPage> {
  bool _isLoading = true;
  final List<PartItem> _parts = [];
  String _searchQuery = '';
  final TextEditingController _searchController = TextEditingController();

  @override
  void initState() {
    super.initState();
    _loadData();
  }

  @override
  void dispose() {
    _searchController.dispose();
    super.dispose();
  }

  Future<void> _loadData() async {
    // Simulación de carga de datos
    await Future.delayed(const Duration(milliseconds: 1200));

    // Datos de ejemplo según la categoría
    // En una aplicación real estos datos vendrían de una base de datos o API
    setState(() {
      _isLoading = false;
    });
  }

  @override
  Widget build(BuildContext context) {
    final themeProvider = Provider.of<ThemeProvider>(context);
    final args =
        ModalRoute.of(context)!.settings.arguments as Map<String, dynamic>;
    final category = args['category'] as String;
    final categoryKey = args['categoryKey'] as String;

    // Generar datos de piezas según la categoría
    if (_parts.isEmpty && !_isLoading) {
      _generatePartsForCategory(categoryKey);
    }

    final isDarkMode = themeProvider.isDarkMode;

    return Scaffold(
      appBar: AppBar(
        title: Text(
          category,
          style: GoogleFonts.cairo(
            fontSize: 20,
            fontWeight: FontWeight.bold,
          ),
        ),
        actions: [
          IconButton(
            icon: Icon(
              isDarkMode ? Icons.wb_sunny : Icons.nightlight_round,
              color: AppTheme.primaryColor,
            ),
            onPressed: () => themeProvider.toggleTheme(),
            tooltip: isDarkMode ? 'الوضع المشمس' : 'الوضع الليلي',
          ),
        ],
      ),
      body: Container(
        decoration: BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
            colors: isDarkMode
                ? [
                    AppTheme.darkBackgroundColor,
                    AppTheme.darkCardColor,
                  ]
                : [
                    AppTheme.lightBackgroundColor,
                    Colors.white,
                  ],
          ),
        ),
        child: Padding(
          padding: const EdgeInsets.all(16.0),
          child: Column(
            children: [
              Container(
                decoration: BoxDecoration(
                  color: isDarkMode ? AppTheme.darkCardColor : Colors.white,
                  borderRadius: BorderRadius.circular(12),
                  boxShadow: [
                    BoxShadow(
                      color: Colors.black.withOpacity(0.05),
                      blurRadius: 10,
                      offset: const Offset(0, 2),
                    ),
                  ],
                ),
                child: TextField(
                  controller: _searchController,
                  onChanged: (value) {
                    setState(() {
                      _searchQuery = value;
                    });
                  },
                  decoration: InputDecoration(
                    hintText: 'البحث عن قطع غيار ${category.toLowerCase()}...',
                    prefixIcon: const Icon(
                      Icons.search,
                      color: AppTheme.primaryColor,
                    ),
                    suffixIcon: _searchQuery.isNotEmpty
                        ? IconButton(
                            icon: const Icon(Icons.clear),
                            onPressed: () {
                              setState(() {
                                _searchQuery = '';
                                _searchController.clear();
                              });
                            },
                          )
                        : null,
                    border: InputBorder.none,
                    contentPadding: const EdgeInsets.symmetric(
                      horizontal: 16,
                      vertical: 12,
                    ),
                  ),
                ),
              ),
              const SizedBox(height: 24),
              Expanded(
                child: _isLoading
                    ? const Center(
                        child: CircularProgressIndicator(),
                      )
                    : _buildPartsList(),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildPartsList() {
    // Filtrar piezas según la búsqueda
    final filteredParts = _parts
        .where((part) =>
            _searchQuery.isEmpty ||
            part.name.toLowerCase().contains(_searchQuery.toLowerCase()) ||
            part.description.toLowerCase().contains(_searchQuery.toLowerCase()))
        .toList();

    if (filteredParts.isEmpty) {
      return Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(
              Icons.search_off,
              size: 64,
              color: Colors.grey[400],
            ),
            const SizedBox(height: 16),
            Text(
              'لم يتم العثور على قطع غيار',
              style: GoogleFonts.tajawal(
                fontSize: 18,
                color: Colors.grey[600],
              ),
            ),
          ],
        ),
      );
    }

    return ListView.builder(
      itemCount: filteredParts.length,
      itemBuilder: (context, index) {
        final part = filteredParts[index];
        return _buildPartCard(part);
      },
    );
  }

  Widget _buildPartCard(PartItem part) {
    final isDarkMode = Provider.of<ThemeProvider>(context).isDarkMode;

    return Container(
      margin: const EdgeInsets.only(bottom: 16),
      decoration: BoxDecoration(
        color: isDarkMode ? AppTheme.darkCardColor : Colors.white,
        borderRadius: BorderRadius.circular(12),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.05),
            blurRadius: 10,
            offset: const Offset(0, 2),
          ),
        ],
      ),
      child: Material(
        color: Colors.transparent,
        borderRadius: BorderRadius.circular(12),
        child: InkWell(
          borderRadius: BorderRadius.circular(12),
          onTap: () {
            // Navegar a la página de detalles del producto con el ID
            Navigator.pushNamed(
              context,
              '/product-details',
              arguments: part.id,
            );
          },
          child: Padding(
            padding: const EdgeInsets.all(16),
            child: Row(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                ClipRRect(
                  borderRadius: BorderRadius.circular(8),
                  child: Image.network(
                    part.imageUrl,
                    width: 100,
                    height: 100,
                    fit: BoxFit.cover,
                    errorBuilder: (context, error, stackTrace) {
                      return Container(
                        width: 100,
                        height: 100,
                        color: Colors.grey[300],
                        child: const Icon(
                          Icons.image_not_supported,
                          color: Colors.grey,
                        ),
                      );
                    },
                  ),
                ),
                const SizedBox(width: 16),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        part.name,
                        style: GoogleFonts.cairo(
                          fontSize: 16,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                      const SizedBox(height: 4),
                      Text(
                        part.description,
                        style: GoogleFonts.tajawal(
                          fontSize: 14,
                          color: isDarkMode ? Colors.white70 : Colors.black54,
                        ),
                        maxLines: 2,
                        overflow: TextOverflow.ellipsis,
                      ),
                      const SizedBox(height: 8),
                      Row(
                        children: [
                          Icon(
                            Icons.star,
                            color: Colors.amber,
                            size: 18,
                          ),
                          const SizedBox(width: 4),
                          Text(
                            '${part.rating}',
                            style: TextStyle(
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                          const SizedBox(width: 16),
                          Container(
                            padding: const EdgeInsets.symmetric(
                              horizontal: 8,
                              vertical: 4,
                            ),
                            decoration: BoxDecoration(
                              color: part.inStock
                                  ? Colors.green[100]
                                  : Colors.red[100],
                              borderRadius: BorderRadius.circular(4),
                            ),
                            child: Text(
                              part.inStock ? 'متوفر' : 'غير متوفر',
                              style: TextStyle(
                                color: part.inStock
                                    ? Colors.green[800]
                                    : Colors.red[800],
                                fontSize: 12,
                                fontWeight: FontWeight.bold,
                              ),
                            ),
                          ),
                        ],
                      ),
                      const SizedBox(height: 8),
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Text(
                            '${part.price} ريال',
                            style: GoogleFonts.tajawal(
                              fontSize: 16,
                              fontWeight: FontWeight.bold,
                              color: AppTheme.primaryColor,
                            ),
                          ),
                          ElevatedButton.icon(
                            onPressed: part.inStock
                                ? () {
                                    _addToCart(part);
                                  }
                                : null,
                            icon: const Icon(
                              Icons.shopping_cart,
                              size: 18,
                            ),
                            label: const Text('إضافة للسلة'),
                            style: ElevatedButton.styleFrom(
                              backgroundColor: AppTheme.primaryColor,
                              foregroundColor: Colors.white,
                              shape: RoundedRectangleBorder(
                                borderRadius: BorderRadius.circular(8),
                              ),
                              padding: const EdgeInsets.symmetric(
                                horizontal: 12,
                                vertical: 8,
                              ),
                            ),
                          ),
                        ],
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  void _addToCart(PartItem part) {
    final cartProvider = Provider.of<CartProvider>(context, listen: false);

    cartProvider.addItem(
      CartItem(
        productId: part.id,
        name: part.name,
        price: part.price,
        quantity: 1,
        imageUrl: part.imageUrl,
      ),
    );

    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text('تمت إضافة ${part.name} إلى سلة المشتريات'),
        backgroundColor: AppTheme.successColor,
        duration: const Duration(seconds: 2),
        action: SnackBarAction(
          label: 'عرض السلة',
          textColor: Colors.white,
          onPressed: () {
            Navigator.pushNamed(context, '/cart');
          },
        ),
      ),
    );
  }

  void _generatePartsForCategory(String categoryKey) {
    // Generar datos de ejemplo según la categoría
    final List<PartItem> parts = [];

    switch (categoryKey) {
      case 'محرك':
        parts.addAll([
          PartItem(
            id: 'engine-1',
            name: 'مضخة زيت المحرك',
            description:
                'مضخة زيت المحرك عالية الجودة متوافقة مع معظم السيارات اليابانية',
            price: 250.0,
            rating: 4.7,
            inStock: true,
            imageUrl: 'https://via.placeholder.com/150?text=Oil+Pump',
          ),
          PartItem(
            id: 'engine-2',
            name: 'حلقات المكبس',
            description:
                'طقم حلقات مكبس من الفولاذ المقاوم للصدأ بمقاسات مختلفة',
            price: 120.0,
            rating: 4.5,
            inStock: true,
            imageUrl: 'https://via.placeholder.com/150?text=Piston+Rings',
          ),
          PartItem(
            id: 'engine-3',
            name: 'طقم سدادات المحرك',
            description: 'طقم سدادات كامل للمحرك مصنوع من مواد عالية الجودة',
            price: 180.0,
            rating: 4.2,
            inStock: false,
            imageUrl: 'https://via.placeholder.com/150?text=Gasket+Set',
          ),
        ]);
        break;
      case 'فرامل':
        parts.addAll([
          PartItem(
            id: 'brake-1',
            name: 'قرص فرامل أمامي',
            description: 'قرص فرامل أمامي مهوى لتبديد الحرارة بكفاءة',
            price: 150.0,
            rating: 4.8,
            inStock: true,
            imageUrl: 'https://via.placeholder.com/150?text=Brake+Disc',
          ),
          PartItem(
            id: 'brake-2',
            name: 'تيل فرامل خلفي',
            description:
                'تيل فرامل خلفي مصنوع من مواد عالية الجودة لأداء ممتاز',
            price: 90.0,
            rating: 4.6,
            inStock: true,
            imageUrl: 'https://via.placeholder.com/150?text=Brake+Pads',
          ),
          PartItem(
            id: 'brake-3',
            name: 'اسطوانة الفرامل الرئيسية',
            description:
                'اسطوانة الفرامل الرئيسية تتوافق مع معظم السيارات الأوروبية',
            price: 220.0,
            rating: 4.4,
            inStock: true,
            imageUrl: 'https://via.placeholder.com/150?text=Master+Cylinder',
          ),
        ]);
        break;
      default:
        // Para otras categorías generamos datos genéricos
        for (int i = 1; i <= 5; i++) {
          parts.add(
            PartItem(
              id: '$categoryKey-$i',
              name: 'قطعة غيار $categoryKey ${i}',
              description: 'وصف تفصيلي لقطعة غيار $categoryKey رقم $i للسيارات',
              price: 100.0 + (i * 30),
              rating: 4.0 + (i % 10) / 10,
              inStock: i % 3 != 0,
              imageUrl: 'https://via.placeholder.com/150?text=$categoryKey+$i',
            ),
          );
        }
    }

    setState(() {
      _parts.addAll(parts);
    });
  }
}

class PartItem {
  final String id;
  final String name;
  final String description;
  final double price;
  final double rating;
  final bool inStock;
  final String imageUrl;

  PartItem({
    required this.id,
    required this.name,
    required this.description,
    required this.price,
    required this.rating,
    required this.inStock,
    required this.imageUrl,
  });
}
