import 'package:flutter/material.dart';
import 'package:faz3a_car/core/theme/app_theme.dart';
import 'package:provider/provider.dart';
import 'package:faz3a_car/main.dart';
import 'package:google_fonts/google_fonts.dart';

class PaymentMethodsPage extends StatelessWidget {
  const PaymentMethodsPage({super.key});

  @override
  Widget build(BuildContext context) {
    final themeProvider = Provider.of<ThemeProvider>(context);
    final isDarkMode = themeProvider.isDarkMode;

    return Scaffold(
      appBar: AppBar(
        title: Text(
          'طرق الدفع',
          style: GoogleFonts.cairo(
            fontSize: 20,
            fontWeight: FontWeight.bold,
          ),
        ),
        actions: [
          IconButton(
            icon: Icon(
              isDarkMode ? Icons.wb_sunny : Icons.nightlight_round,
              color: AppTheme.primaryColor,
            ),
            onPressed: () => themeProvider.toggleTheme(),
            tooltip: isDarkMode ? 'الوضع المشمس' : 'الوضع الليلي',
          ),
        ],
      ),
      body: Container(
        decoration: BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
            colors: isDarkMode
                ? [
                    AppTheme.darkBackgroundColor,
                    AppTheme.darkCardColor,
                  ]
                : [
                    AppTheme.lightBackgroundColor,
                    Colors.white,
                  ],
          ),
        ),
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(16.0),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              // Introduction section
              Text(
                'طرق الدفع المتاحة',
                style: GoogleFonts.cairo(
                  fontSize: 24,
                  fontWeight: FontWeight.bold,
                ),
              ),
              const SizedBox(height: 8),
              Text(
                'نوفر لك طرق دفع متنوعة لتسهيل عملية الشراء والدفع بما يناسب احتياجاتك',
                style: GoogleFonts.tajawal(
                  fontSize: 16,
                  color: isDarkMode ? Colors.white70 : Colors.black54,
                ),
              ),
              const SizedBox(height: 24),

              // Cash on delivery
              _buildPaymentMethodCard(
                context,
                title: 'الدفع عند الاستلام',
                description: 'يمكنك الدفع نقدًا عند استلام الطلب مباشرة',
                icon: Icons.payments_outlined,
                color: Colors.green.shade600,
                details: [
                  'لا توجد رسوم إضافية للدفع عند الاستلام',
                  'متاح للطلبات داخل المدينة',
                  'الحد الأقصى للطلب هو 5000 ريال',
                ],
                isRecommended: true,
              ),

              const SizedBox(height: 16),

              // Credit card payment
              _buildPaymentMethodCard(
                context,
                title: 'بطاقات الائتمان والخصم',
                description: 'ادفع بشكل آمن باستخدام بطاقتك المصرفية',
                icon: Icons.credit_card,
                color: Colors.blue.shade600,
                details: [
                  'نقبل فيزا وماستركارد ومدى',
                  'يتم تشفير معلومات البطاقة بالكامل',
                  'تأكيد فوري للطلب بعد نجاح الدفع',
                ],
                supportedCards: [
                  'assets/images/visa.png',
                  'assets/images/mastercard.png',
                  'assets/images/mada.png',
                ],
              ),

              const SizedBox(height: 16),

              // Bank transfer
              _buildPaymentMethodCard(
                context,
                title: 'التحويل البنكي',
                description: 'حول المبلغ مباشرة إلى حسابنا البنكي',
                icon: Icons.account_balance,
                color: Colors.purple.shade600,
                details: [
                  'يجب إرسال إشعار التحويل بعد إتمام العملية',
                  'سيتم تأكيد الطلب بعد التحقق من التحويل',
                  'عادةً ما يستغرق التأكيد من 1-2 يوم عمل',
                ],
                bankAccounts: [
                  BankAccount(
                    bankName: 'البنك الأهلي السعودي',
                    accountNumber: 'SA0123456789012345678901',
                    accountHolder: 'شركة فزعة كار للسيارات',
                  ),
                  BankAccount(
                    bankName: 'مصرف الراجحي',
                    accountNumber: 'SA9876543210987654321098',
                    accountHolder: 'شركة فزعة كار للسيارات',
                  ),
                ],
              ),

              const SizedBox(height: 16),

              // Digital wallets
              _buildPaymentMethodCard(
                context,
                title: 'المحافظ الإلكترونية',
                description: 'استخدم محفظتك الإلكترونية المفضلة لإتمام الدفع',
                icon: Icons.account_balance_wallet,
                color: Colors.amber.shade600,
                details: [
                  'سهولة وسرعة في إتمام عملية الدفع',
                  'متاح على مدار الساعة',
                  'تأكيد فوري للطلب بعد نجاح الدفع',
                ],
                wallets: [
                  'Apple Pay',
                  'STCPay',
                  'Urpay',
                ],
              ),

              const SizedBox(height: 16),

              // Buy now pay later
              _buildPaymentMethodCard(
                context,
                title: 'اشتري الآن وادفع لاحقًا',
                description: 'خيارات تمويل متعددة للدفع بالتقسيط',
                icon: Icons.access_time,
                color: Colors.teal.shade600,
                details: [
                  'متاح للطلبات التي تزيد عن 500 ريال',
                  'تقسيط على 3 أو 6 أو 12 شهرًا',
                  'بدون دفعة مقدمة (حسب الأهلية الائتمانية)',
                ],
                financeOptions: [
                  'تمارا - Tamara',
                  'تبارك - Tabby',
                ],
              ),

              const SizedBox(height: 24),

              // Payment security section
              Container(
                padding: const EdgeInsets.all(16),
                decoration: BoxDecoration(
                  color: isDarkMode ? AppTheme.darkCardColor : Colors.white,
                  borderRadius: BorderRadius.circular(16),
                  boxShadow: [
                    BoxShadow(
                      color: Colors.black.withOpacity(0.05),
                      blurRadius: 10,
                      offset: const Offset(0, 2),
                    ),
                  ],
                ),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      children: [
                        Icon(
                          Icons.security,
                          color: AppTheme.primaryColor,
                          size: 24,
                        ),
                        const SizedBox(width: 8),
                        Text(
                          'أمان المدفوعات',
                          style: GoogleFonts.cairo(
                            fontSize: 18,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(height: 16),
                    Text(
                      'نحن نتخذ جميع الإجراءات اللازمة لضمان أمان معاملاتك المالية. جميع المعلومات المالية مشفرة بمعايير SSL العالمية، ونستخدم بوابات دفع معتمدة ومرخصة من المؤسسات المالية المحلية والعالمية.',
                      style: GoogleFonts.tajawal(
                        height: 1.5,
                        color: isDarkMode ? Colors.white70 : Colors.black87,
                      ),
                    ),
                  ],
                ),
              ),

              const SizedBox(height: 24),

              // Help button
              SizedBox(
                width: double.infinity,
                child: ElevatedButton.icon(
                  onPressed: () {
                    // Navigate to help page or show help dialog
                    _showHelpDialog(context);
                  },
                  style: ElevatedButton.styleFrom(
                    backgroundColor: AppTheme.primaryColor,
                    foregroundColor: Colors.white,
                    padding: const EdgeInsets.symmetric(vertical: 12),
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(8),
                    ),
                  ),
                  icon: const Icon(Icons.help_outline),
                  label: Text(
                    'مساعدة في الدفع',
                    style: GoogleFonts.cairo(
                      fontSize: 16,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildPaymentMethodCard(
    BuildContext context, {
    required String title,
    required String description,
    required IconData icon,
    required Color color,
    required List<String> details,
    bool isRecommended = false,
    List<String>? supportedCards,
    List<BankAccount>? bankAccounts,
    List<String>? wallets,
    List<String>? financeOptions,
  }) {
    final isDarkMode = Provider.of<ThemeProvider>(context).isDarkMode;

    return Container(
      decoration: BoxDecoration(
        color: isDarkMode ? AppTheme.darkCardColor : Colors.white,
        borderRadius: BorderRadius.circular(16),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.05),
            blurRadius: 10,
            offset: const Offset(0, 2),
          ),
        ],
        border: isRecommended ? Border.all(color: color, width: 2) : null,
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          if (isRecommended)
            Container(
              width: double.infinity,
              padding: const EdgeInsets.symmetric(vertical: 6),
              decoration: BoxDecoration(
                color: color,
                borderRadius: const BorderRadius.only(
                  topLeft: Radius.circular(14),
                  topRight: Radius.circular(14),
                ),
              ),
              child: Text(
                'الخيار الموصى به',
                style: GoogleFonts.cairo(
                  color: Colors.white,
                  fontWeight: FontWeight.bold,
                  fontSize: 12,
                ),
                textAlign: TextAlign.center,
              ),
            ),
          Padding(
            padding: const EdgeInsets.all(16),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    Container(
                      padding: const EdgeInsets.all(10),
                      decoration: BoxDecoration(
                        color: color.withOpacity(0.1),
                        shape: BoxShape.circle,
                      ),
                      child: Icon(
                        icon,
                        color: color,
                        size: 24,
                      ),
                    ),
                    const SizedBox(width: 12),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            title,
                            style: GoogleFonts.cairo(
                              fontSize: 18,
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                          Text(
                            description,
                            style: GoogleFonts.tajawal(
                              fontSize: 14,
                              color:
                                  isDarkMode ? Colors.white70 : Colors.black54,
                            ),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 16),
                const Divider(),
                const SizedBox(height: 12),
                for (final detail in details)
                  Padding(
                    padding: const EdgeInsets.only(bottom: 8),
                    child: Row(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Icon(
                          Icons.check_circle,
                          color: color,
                          size: 18,
                        ),
                        const SizedBox(width: 8),
                        Expanded(
                          child: Text(
                            detail,
                            style: GoogleFonts.tajawal(
                              fontSize: 14,
                              height: 1.3,
                              color:
                                  isDarkMode ? Colors.white70 : Colors.black87,
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),

                // Display supported cards if available
                if (supportedCards != null && supportedCards.isNotEmpty) ...[
                  const SizedBox(height: 16),
                  Text(
                    'البطاقات المدعومة:',
                    style: GoogleFonts.cairo(
                      fontSize: 14,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                  const SizedBox(height: 8),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.start,
                    children: supportedCards.map((cardImage) {
                      return Padding(
                        padding: const EdgeInsets.only(right: 12),
                        child: Container(
                          width: 50,
                          height: 30,
                          decoration: BoxDecoration(
                            color: Colors.white,
                            borderRadius: BorderRadius.circular(4),
                            border: Border.all(color: Colors.grey.shade300),
                          ),
                          child: Icon(
                            cardImage == 'assets/images/visa.png'
                                ? Icons.credit_card
                                : cardImage == 'assets/images/mastercard.png'
                                    ? Icons.credit_card
                                    : Icons.credit_card,
                            size: 20,
                            color: cardImage == 'assets/images/mada.png'
                                ? Colors.green
                                : cardImage == 'assets/images/visa.png'
                                    ? Colors.blue
                                    : Colors.red,
                          ),
                        ),
                      );
                    }).toList(),
                  ),
                ],

                // Display bank accounts if available
                if (bankAccounts != null && bankAccounts.isNotEmpty) ...[
                  const SizedBox(height: 16),
                  Text(
                    'الحسابات البنكية:',
                    style: GoogleFonts.cairo(
                      fontSize: 14,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                  const SizedBox(height: 8),
                  for (final account in bankAccounts)
                    Container(
                      margin: const EdgeInsets.only(bottom: 8),
                      padding: const EdgeInsets.all(10),
                      decoration: BoxDecoration(
                        color: isDarkMode ? Colors.grey[800] : Colors.grey[100],
                        borderRadius: BorderRadius.circular(8),
                      ),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            account.bankName,
                            style: GoogleFonts.cairo(
                              fontWeight: FontWeight.bold,
                              fontSize: 13,
                            ),
                          ),
                          const SizedBox(height: 4),
                          Row(
                            children: [
                              Expanded(
                                child: Text(
                                  account.accountNumber,
                                  style: GoogleFonts.tajawal(
                                    fontSize: 13,
                                    fontWeight: FontWeight.bold,
                                    letterSpacing: 1,
                                  ),
                                ),
                              ),
                              IconButton(
                                onPressed: () {
                                  // Copy to clipboard functionality
                                  // Not implemented in this example
                                  ScaffoldMessenger.of(context).showSnackBar(
                                    SnackBar(
                                      content: Text(
                                        'تم نسخ رقم الحساب',
                                        style: GoogleFonts.cairo(),
                                      ),
                                      duration: const Duration(seconds: 2),
                                    ),
                                  );
                                },
                                icon: const Icon(
                                  Icons.copy,
                                  size: 18,
                                ),
                                padding: EdgeInsets.zero,
                                visualDensity: VisualDensity.compact,
                              ),
                            ],
                          ),
                          Text(
                            'اسم المستفيد: ${account.accountHolder}',
                            style: GoogleFonts.tajawal(
                              fontSize: 12,
                              color:
                                  isDarkMode ? Colors.white70 : Colors.black54,
                            ),
                          ),
                        ],
                      ),
                    ),
                ],

                // Display digital wallets if available
                if (wallets != null && wallets.isNotEmpty) ...[
                  const SizedBox(height: 16),
                  Text(
                    'المحافظ الإلكترونية المدعومة:',
                    style: GoogleFonts.cairo(
                      fontSize: 14,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                  const SizedBox(height: 8),
                  Wrap(
                    spacing: 8,
                    runSpacing: 8,
                    children: wallets.map((wallet) {
                      return Container(
                        padding: const EdgeInsets.symmetric(
                          horizontal: 12,
                          vertical: 8,
                        ),
                        decoration: BoxDecoration(
                          color:
                              isDarkMode ? Colors.grey[800] : Colors.grey[100],
                          borderRadius: BorderRadius.circular(20),
                        ),
                        child: Text(
                          wallet,
                          style: GoogleFonts.tajawal(
                            fontSize: 13,
                            color: isDarkMode ? Colors.white70 : Colors.black87,
                          ),
                        ),
                      );
                    }).toList(),
                  ),
                ],

                // Display finance options if available
                if (financeOptions != null && financeOptions.isNotEmpty) ...[
                  const SizedBox(height: 16),
                  Text(
                    'خيارات التقسيط المتاحة:',
                    style: GoogleFonts.cairo(
                      fontSize: 14,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                  const SizedBox(height: 8),
                  Column(
                    children: financeOptions.map((option) {
                      return Padding(
                        padding: const EdgeInsets.only(bottom: 8),
                        child: Row(
                          children: [
                            Icon(
                              Icons.check_circle_outline,
                              size: 16,
                              color: color,
                            ),
                            const SizedBox(width: 8),
                            Text(
                              option,
                              style: GoogleFonts.tajawal(
                                fontSize: 14,
                              ),
                            ),
                          ],
                        ),
                      );
                    }).toList(),
                  ),
                ],
              ],
            ),
          ),
        ],
      ),
    );
  }

  void _showHelpDialog(BuildContext context) {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: Row(
          children: [
            Icon(
              Icons.help,
              color: AppTheme.primaryColor,
            ),
            const SizedBox(width: 8),
            Text(
              'مساعدة في الدفع',
              style: GoogleFonts.cairo(
                fontWeight: FontWeight.bold,
              ),
            ),
          ],
        ),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              'إذا كنت تواجه مشكلة في إتمام عملية الدفع، يرجى التواصل مع خدمة العملاء:',
              style: GoogleFonts.tajawal(),
            ),
            const SizedBox(height: 16),
            Row(
              children: [
                Icon(
                  Icons.phone,
                  size: 18,
                  color: AppTheme.primaryColor,
                ),
                const SizedBox(width: 8),
                Text(
                  '920001234',
                  style: GoogleFonts.tajawal(
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ],
            ),
            const SizedBox(height: 8),
            Row(
              children: [
                Icon(
                  Icons.email,
                  size: 18,
                  color: AppTheme.primaryColor,
                ),
                const SizedBox(width: 8),
                Text(
                  'support@faz3acar.com',
                  style: GoogleFonts.tajawal(
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ],
            ),
            const SizedBox(height: 8),
            Row(
              children: [
                Icon(
                  Icons.access_time,
                  size: 18,
                  color: AppTheme.primaryColor,
                ),
                const SizedBox(width: 8),
                Text(
                  'أوقات العمل: 8 صباحًا - 10 مساءً',
                  style: GoogleFonts.tajawal(),
                ),
              ],
            ),
          ],
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.of(context).pop(),
            child: Text(
              'إغلاق',
              style: GoogleFonts.cairo(
                fontWeight: FontWeight.bold,
                color: AppTheme.primaryColor,
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class BankAccount {
  final String bankName;
  final String accountNumber;
  final String accountHolder;

  BankAccount({
    required this.bankName,
    required this.accountNumber,
    required this.accountHolder,
  });
}
