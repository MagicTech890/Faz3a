import 'dart:convert';
import 'package:http/http.dart' as http;
import 'package:shared_preferences/shared_preferences.dart';

class OdooService {
  static const String _prefsKey = 'odoo_config';
  late String _baseUrl;
  late String _database;
  late String _username;
  late String _password;
  String? _uid;
  final SharedPreferences _prefs;

  OdooService(this._prefs) {
    _loadConfig();
  }

  void _loadConfig() {
    final config = _prefs.getString(_prefsKey);
    if (config != null) {
      final Map<String, dynamic> configMap = json.decode(config);
      _baseUrl = configMap['url'];
      _database = configMap['database'];
      _username = configMap['username'];
      _password = configMap['password'];
      _uid = configMap['uid'];
    }
  }

  Future<void> saveConfig({
    required String url,
    required String database,
    required String username,
    required String password,
  }) async {
    _baseUrl = url;
    _database = database;
    _username = username;
    _password = password;

    final config = {
      'url': url,
      'database': database,
      'username': username,
      'password': password,
      'uid': _uid,
    };

    await _prefs.setString(_prefsKey, json.encode(config));
  }

  Future<bool> authenticate() async {
    try {
      final response = await http.post(
        Uri.parse('$_baseUrl/web/session/authenticate'),
        headers: {'Content-Type': 'application/json'},
        body: json.encode({
          'jsonrpc': '2.0',
          'method': 'call',
          'params': {
            'db': _database,
            'login': _username,
            'password': _password,
          },
        }),
      );

      if (response.statusCode == 200) {
        final result = json.decode(response.body);
        if (result['result'] != null) {
          _uid = result['result']['uid'].toString();
          await saveConfig(
            url: _baseUrl,
            database: _database,
            username: _username,
            password: _password,
          );
          return true;
        }
      }
      return false;
    } catch (e) {
      print('Authentication error: $e');
      return false;
    }
  }

  Future<Map<String, dynamic>> callKw({
    required String model,
    required String method,
    required List args,
    Map<String, dynamic>? kwargs,
  }) async {
    try {
      final response = await http.post(
        Uri.parse('$_baseUrl/web/dataset/call_kw'),
        headers: {'Content-Type': 'application/json'},
        body: json.encode({
          'jsonrpc': '2.0',
          'method': 'call',
          'params': {
            'model': model,
            'method': method,
            'args': args,
            'kwargs': kwargs ?? {},
          },
        }),
      );

      if (response.statusCode == 200) {
        final result = json.decode(response.body);
        if (result['result'] != null) {
          return result['result'];
        }
      }
      return {};
    } catch (e) {
      print('API call error: $e');
      return {};
    }
  }

  Future<List<Map<String, dynamic>>> searchRead({
    required String model,
    List<List<dynamic>> domain = const [],
    List<String> fields = const [],
    int offset = 0,
    int limit = 0,
  }) async {
    try {
      final response = await http.post(
        Uri.parse('$_baseUrl/web/dataset/search_read'),
        headers: {'Content-Type': 'application/json'},
        body: json.encode({
          'jsonrpc': '2.0',
          'method': 'call',
          'params': {
            'model': model,
            'domain': domain,
            'fields': fields,
            'offset': offset,
            'limit': limit,
          },
        }),
      );

      if (response.statusCode == 200) {
        final result = json.decode(response.body);
        if (result['result'] != null && result['result']['records'] != null) {
          return List<Map<String, dynamic>>.from(result['result']['records']);
        }
      }
      return [];
    } catch (e) {
      print('Search read error: $e');
      return [];
    }
  }

  Future<bool> create({
    required String model,
    required Map<String, dynamic> values,
  }) async {
    try {
      final result = await callKw(
        model: model,
        method: 'create',
        args: [values],
      );
      return result.isNotEmpty;
    } catch (e) {
      print('Create error: $e');
      return false;
    }
  }

  Future<bool> write({
    required String model,
    required int id,
    required Map<String, dynamic> values,
  }) async {
    try {
      final result = await callKw(
        model: model,
        method: 'write',
        args: [
          [id],
          values
        ],
      );
      return result.isNotEmpty;
    } catch (e) {
      print('Write error: $e');
      return false;
    }
  }

  Future<bool> unlink({
    required String model,
    required int id,
  }) async {
    try {
      final result = await callKw(
        model: model,
        method: 'unlink',
        args: [
          [id]
        ],
      );
      return result.isNotEmpty;
    } catch (e) {
      print('Unlink error: $e');
      return false;
    }
  }

  Future<Map<String, dynamic>> getModuleInfo(String moduleName) async {
    try {
      final result = await callKw(
        model: 'ir.module.module',
        method: 'search_read',
        args: [
          [
            ['name', '=', moduleName]
          ],
          ['name', 'state', 'latest_version', 'installed_version'],
        ],
      );

      if (result.isNotEmpty && result is List) {
        return Map<String, dynamic>.from(result[0]);
      }
      return {};
    } catch (e) {
      print('Get module info error: $e');
      return {};
    }
  }

  Future<bool> installModule(String moduleName) async {
    try {
      final result = await callKw(
        model: 'ir.module.module',
        method: 'button_immediate_install',
        args: [
          [moduleName],
        ],
      );
      return result.isNotEmpty;
    } catch (e) {
      print('Install module error: $e');
      return false;
    }
  }

  Future<bool> uninstallModule(String moduleName) async {
    try {
      final result = await callKw(
        model: 'ir.module.module',
        method: 'button_immediate_uninstall',
        args: [
          [moduleName],
        ],
      );
      return result.isNotEmpty;
    } catch (e) {
      print('Uninstall module error: $e');
      return false;
    }
  }

  Future<Map<String, dynamic>> getSystemInfo() async {
    try {
      final result = await callKw(
        model: 'ir.module.module',
        method: 'get_system_info',
        args: [],
      );
      return result;
    } catch (e) {
      print('Get system info error: $e');
      return {};
    }
  }

  Future<List<Map<String, dynamic>>> getModules() async {
    try {
      final result = await searchRead(
        model: 'ir.module.module',
        fields: ['name', 'state', 'latest_version', 'installed_version'],
      );
      return result;
    } catch (e) {
      print('Get modules error: $e');
      return [];
    }
  }

  Future<Map<String, dynamic>> getStats() async {
    try {
      final sales = await searchRead(
        model: 'sale.order',
        fields: ['amount_total'],
      );

      final purchases = await searchRead(
        model: 'purchase.order',
        fields: ['amount_total'],
      );

      final products = await searchRead(
        model: 'product.product',
        fields: ['qty_available'],
      );

      final employees = await searchRead(
        model: 'hr.employee',
        fields: ['name'],
      );

      return {
        'sales': sales.fold<double>(
            0, (sum, order) => sum + (order['amount_total'] ?? 0)),
        'purchases': purchases.fold<double>(
            0, (sum, order) => sum + (order['amount_total'] ?? 0)),
        'products': products.length,
        'employees': employees.length,
      };
    } catch (e) {
      print('Get stats error: $e');
      return {};
    }
  }
}
