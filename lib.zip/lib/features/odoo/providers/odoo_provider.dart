import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../services/odoo_service.dart';

class OdooProvider extends ChangeNotifier {
  late OdooService _service;
  bool _isLoading = false;
  bool _isConnected = false;
  Map<String, dynamic> _stats = {};
  List<Map<String, dynamic>> _modules = [];

  bool get isLoading => _isLoading;
  bool get isConnected => _isConnected;
  Map<String, dynamic> get stats => _stats;
  List<Map<String, dynamic>> get modules => _modules;

  OdooProvider() {
    _init();
  }

  Future<void> _init() async {
    final prefs = await SharedPreferences.getInstance();
    _service = OdooService(prefs);
    await checkConnection();
  }

  Future<void> checkConnection() async {
    _isLoading = true;
    notifyListeners();

    _isConnected = await _service.authenticate();
    if (_isConnected) {
      await Future.wait([
        loadStats(),
        loadModules(),
      ]);
    }

    _isLoading = false;
    notifyListeners();
  }

  Future<void> connect({
    required String url,
    required String database,
    required String username,
    required String password,
  }) async {
    _isLoading = true;
    notifyListeners();

    await _service.saveConfig(
      url: url,
      database: database,
      username: username,
      password: password,
    );

    await checkConnection();
  }

  Future<void> loadStats() async {
    _stats = await _service.getStats();
    notifyListeners();
  }

  Future<void> loadModules() async {
    _modules = await _service.getModules();
    notifyListeners();
  }

  Future<bool> installModule(String moduleName) async {
    _isLoading = true;
    notifyListeners();

    final result = await _service.installModule(moduleName);
    await loadModules();

    _isLoading = false;
    notifyListeners();

    return result;
  }

  Future<bool> uninstallModule(String moduleName) async {
    _isLoading = true;
    notifyListeners();

    final result = await _service.uninstallModule(moduleName);
    await loadModules();

    _isLoading = false;
    notifyListeners();

    return result;
  }

  Future<Map<String, dynamic>> getModuleInfo(String moduleName) async {
    return await _service.getModuleInfo(moduleName);
  }

  Future<Map<String, dynamic>> getSystemInfo() async {
    return await _service.getSystemInfo();
  }

  Future<bool> create({
    required String model,
    required Map<String, dynamic> values,
  }) async {
    _isLoading = true;
    notifyListeners();

    final result = await _service.create(
      model: model,
      values: values,
    );

    _isLoading = false;
    notifyListeners();

    return result;
  }

  Future<bool> write({
    required String model,
    required int id,
    required Map<String, dynamic> values,
  }) async {
    _isLoading = true;
    notifyListeners();

    final result = await _service.write(
      model: model,
      id: id,
      values: values,
    );

    _isLoading = false;
    notifyListeners();

    return result;
  }

  Future<bool> unlink({
    required String model,
    required int id,
  }) async {
    _isLoading = true;
    notifyListeners();

    final result = await _service.unlink(
      model: model,
      id: id,
    );

    _isLoading = false;
    notifyListeners();

    return result;
  }

  Future<List<Map<String, dynamic>>> searchRead({
    required String model,
    List<List<dynamic>> domain = const [],
    List<String> fields = const [],
    int offset = 0,
    int limit = 0,
  }) async {
    return await _service.searchRead(
      model: model,
      domain: domain,
      fields: fields,
      offset: offset,
      limit: limit,
    );
  }
}
