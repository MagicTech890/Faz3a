import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:faz3a_car/core/theme/app_theme.dart';
import 'dart:math' as math;

class AnalyticsDashboard extends StatefulWidget {
  const AnalyticsDashboard({super.key});

  @override
  State<AnalyticsDashboard> createState() => _AnalyticsDashboardState();
}

class _AnalyticsDashboardState extends State<AnalyticsDashboard> {
  final List<String> _timeRanges = ['اليوم', 'الأسبوع', 'الشهر', 'السنة'];
  String _selectedTimeRange = 'الشهر';

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(
          'لوحة التحليلات',
          style: GoogleFonts.tajawal(
            fontSize: 24,
            fontWeight: FontWeight.bold,
          ),
        ),
        actions: [
          DropdownButton<String>(
            value: _selectedTimeRange,
            items: _timeRanges.map((range) {
              return DropdownMenuItem(
                value: range,
                child: Text(range),
              );
            }).toList(),
            onChanged: (value) {
              setState(() {
                _selectedTimeRange = value!;
              });
            },
          ),
          const SizedBox(width: 16),
        ],
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(20),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Alerts and Notifications Section
            _buildAlertSection(),
            const SizedBox(height: 20),

            // Key Metrics
            Row(
              children: [
                _buildMetricCard(
                  'إجمالي المبيعات',
                  '25,300 ريال',
                  Icons.trending_up,
                  Colors.green,
                  '12.5%',
                  true,
                ),
                const SizedBox(width: 20),
                _buildMetricCard(
                  'عدد الطلبات',
                  '142 طلب',
                  Icons.trending_up,
                  Colors.green,
                  '8.3%',
                  true,
                ),
                const SizedBox(width: 20),
                _buildMetricCard(
                  'معدل التحويل',
                  '4.2%',
                  Icons.trending_down,
                  Colors.red,
                  '1.5%',
                  false,
                ),
                const SizedBox(width: 20),
                _buildMetricCard(
                  'متوسط قيمة الطلب',
                  '178 ريال',
                  Icons.trending_up,
                  Colors.green,
                  '3.7%',
                  true,
                ),
              ],
            ),
            const SizedBox(height: 30),

            // Charts Section
            Row(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Expanded(
                  flex: 2,
                  child: _buildChartContainer(
                    'المبيعات والطلبات',
                    SizedBox(
                      height: 300,
                      child: _buildSalesChart(),
                    ),
                  ),
                ),
                const SizedBox(width: 20),
                Expanded(
                  flex: 1,
                  child: _buildChartContainer(
                    'أكثر المنتجات مبيعاً',
                    SizedBox(
                      height: 300,
                      child: _buildTopProductsChart(),
                    ),
                  ),
                ),
              ],
            ),
            const SizedBox(height: 30),

            // Performance Metrics
            Row(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Expanded(
                  child: _buildChartContainer(
                    'أداء النظام',
                    _buildPerformanceMetrics(),
                  ),
                ),
                const SizedBox(width: 20),
                Expanded(
                  child: _buildChartContainer(
                    'تقرير المخزون',
                    _buildInventoryReport(),
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildAlertSection() {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Colors.red.shade50,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: Colors.red.shade200),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Icon(Icons.warning_amber_rounded, color: Colors.red.shade700),
              const SizedBox(width: 8),
              Text(
                'تنبيهات مهمة تحتاج للمراجعة',
                style: GoogleFonts.tajawal(
                  fontWeight: FontWeight.bold,
                  fontSize: 16,
                  color: Colors.red.shade700,
                ),
              ),
            ],
          ),
          const SizedBox(height: 16),
          Wrap(
            spacing: 16,
            runSpacing: 16,
            children: [
              _buildAlertChip('3 منتجات نفذت من المخزون', Colors.red),
              _buildAlertChip('5 طلبات متأخرة عن موعد التسليم', Colors.orange),
              _buildAlertChip('2 شكاوى عملاء جديدة', Colors.amber),
              _buildAlertChip('7 عمليات دفع معلقة', Colors.blue),
            ],
          ),
        ],
      ),
    );
  }

  Widget _buildAlertChip(String label, Color color) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
      decoration: BoxDecoration(
        color: color.withOpacity(0.1),
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: color.withOpacity(0.3)),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(Icons.circle, size: 10, color: color),
          const SizedBox(width: 8),
          Text(
            label,
            style: GoogleFonts.tajawal(
              color: color,
              fontWeight: FontWeight.bold,
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildMetricCard(String title, String value, IconData trendIcon,
      Color trendColor, String percentChange, bool isPositive) {
    return Expanded(
      child: Container(
        padding: const EdgeInsets.all(20),
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(12),
          boxShadow: [
            BoxShadow(
              color: Colors.grey.withOpacity(0.1),
              spreadRadius: 1,
              blurRadius: 5,
              offset: const Offset(0, 2),
            ),
          ],
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              title,
              style: GoogleFonts.tajawal(
                color: Colors.grey[600],
                fontSize: 14,
              ),
            ),
            const SizedBox(height: 10),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text(
                  value,
                  style: GoogleFonts.tajawal(
                    fontSize: 24,
                    fontWeight: FontWeight.bold,
                  ),
                ),
                Container(
                  padding:
                      const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                  decoration: BoxDecoration(
                    color: trendColor.withOpacity(0.1),
                    borderRadius: BorderRadius.circular(4),
                  ),
                  child: Row(
                    children: [
                      Icon(trendIcon, color: trendColor, size: 16),
                      const SizedBox(width: 4),
                      Text(
                        percentChange,
                        style: GoogleFonts.tajawal(
                          color: trendColor,
                          fontWeight: FontWeight.bold,
                          fontSize: 12,
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),
            const SizedBox(height: 16),
            ClipRRect(
              borderRadius: BorderRadius.circular(4),
              child: LinearProgressIndicator(
                value: 0.7,
                backgroundColor: Colors.grey[200],
                color: isPositive ? Colors.green : Colors.red,
                minHeight: 4,
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildChartContainer(String title, Widget content) {
    return Container(
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(12),
        boxShadow: [
          BoxShadow(
            color: Colors.grey.withOpacity(0.1),
            spreadRadius: 1,
            blurRadius: 5,
            offset: const Offset(0, 2),
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            title,
            style: GoogleFonts.tajawal(
              fontSize: 18,
              fontWeight: FontWeight.bold,
            ),
          ),
          const SizedBox(height: 20),
          content,
        ],
      ),
    );
  }

  Widget _buildSalesChart() {
    return Column(
      children: [
        Expanded(
          child: Row(
            children: List.generate(
              12,
              (index) => Expanded(
                child: Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 2),
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.end,
                    children: [
                      Container(
                        height: _getRandomHeight(200),
                        decoration: BoxDecoration(
                          color: AppTheme.primaryColor,
                          borderRadius: const BorderRadius.vertical(
                              top: Radius.circular(4)),
                        ),
                      ),
                      const SizedBox(height: 8),
                      Container(
                        height: _getRandomHeight(100),
                        decoration: BoxDecoration(
                          color: Colors.orange,
                          borderRadius: const BorderRadius.vertical(
                              top: Radius.circular(4)),
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ),
          ),
        ),
        const SizedBox(height: 10),
        Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: List.generate(
            12,
            (index) => Text(
              _getMonthName(index),
              style: GoogleFonts.tajawal(
                color: Colors.grey[600],
                fontSize: 10,
              ),
            ),
          ),
        ),
        const SizedBox(height: 20),
        Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Row(
              children: [
                Container(
                  width: 12,
                  height: 12,
                  decoration: BoxDecoration(
                    color: AppTheme.primaryColor,
                    borderRadius: BorderRadius.circular(2),
                  ),
                ),
                const SizedBox(width: 8),
                Text(
                  'المبيعات',
                  style: GoogleFonts.tajawal(
                    color: Colors.grey[600],
                    fontSize: 12,
                  ),
                ),
              ],
            ),
            const SizedBox(width: 20),
            Row(
              children: [
                Container(
                  width: 12,
                  height: 12,
                  decoration: BoxDecoration(
                    color: Colors.orange,
                    borderRadius: BorderRadius.circular(2),
                  ),
                ),
                const SizedBox(width: 8),
                Text(
                  'الطلبات',
                  style: GoogleFonts.tajawal(
                    color: Colors.grey[600],
                    fontSize: 12,
                  ),
                ),
              ],
            ),
          ],
        ),
      ],
    );
  }

  Widget _buildTopProductsChart() {
    final products = [
      {'name': 'بطاريات', 'value': 35, 'color': Colors.blue},
      {'name': 'زيوت', 'value': 25, 'color': Colors.green},
      {'name': 'إطارات', 'value': 20, 'color': Colors.orange},
      {'name': 'فرامل', 'value': 15, 'color': Colors.purple},
      {'name': 'أخرى', 'value': 5, 'color': Colors.grey},
    ];

    return Column(
      children: [
        Expanded(
          child: Stack(
            alignment: Alignment.center,
            children: [
              CustomPaint(
                size: const Size(double.infinity, double.infinity),
                painter: PieChartPainter(products),
              ),
              Container(
                width: 80,
                height: 80,
                decoration: BoxDecoration(
                  color: Colors.white,
                  shape: BoxShape.circle,
                  boxShadow: [
                    BoxShadow(
                      color: Colors.grey.withOpacity(0.1),
                      spreadRadius: 1,
                      blurRadius: 5,
                    ),
                  ],
                ),
                child: Center(
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Text(
                        '120',
                        style: GoogleFonts.tajawal(
                          fontSize: 20,
                          fontWeight: FontWeight.bold,
                          color: AppTheme.primaryColor,
                        ),
                      ),
                      Text(
                        'منتج',
                        style: GoogleFonts.tajawal(
                          fontSize: 12,
                          color: Colors.grey[600],
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ],
          ),
        ),
        const SizedBox(height: 20),
        Column(
          children: products.map((product) {
            return Padding(
              padding: const EdgeInsets.only(bottom: 8),
              child: Row(
                children: [
                  Container(
                    width: 12,
                    height: 12,
                    decoration: BoxDecoration(
                      color: product['color'] as Color,
                      borderRadius: BorderRadius.circular(2),
                    ),
                  ),
                  const SizedBox(width: 8),
                  Text(
                    product['name'] as String,
                    style: GoogleFonts.tajawal(
                      color: Colors.grey[800],
                    ),
                  ),
                  const Spacer(),
                  Text(
                    '${product['value']}%',
                    style: GoogleFonts.tajawal(
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                ],
              ),
            );
          }).toList(),
        ),
      ],
    );
  }

  Widget _buildPerformanceMetrics() {
    final metrics = [
      {'name': 'وقت الاستجابة', 'value': '120ms', 'status': 'ممتاز'},
      {'name': 'توافر النظام', 'value': '99.8%', 'status': 'ممتاز'},
      {'name': 'نسبة الأخطاء', 'value': '0.2%', 'status': 'ممتاز'},
      {'name': 'سرعة التحميل', 'value': '1.5s', 'status': 'جيد'},
    ];

    return Column(
      children: metrics.map((metric) {
        return Padding(
          padding: const EdgeInsets.only(bottom: 16),
          child: Row(
            children: [
              Expanded(
                flex: 2,
                child: Text(
                  metric['name'] as String,
                  style: GoogleFonts.tajawal(
                    color: Colors.grey[700],
                  ),
                ),
              ),
              Expanded(
                flex: 1,
                child: Text(
                  metric['value'] as String,
                  style: GoogleFonts.tajawal(
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ),
              Expanded(
                flex: 1,
                child: Container(
                  padding:
                      const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                  decoration: BoxDecoration(
                    color: _getStatusColor(metric['status'] as String)
                        .withOpacity(0.1),
                    borderRadius: BorderRadius.circular(4),
                  ),
                  child: Center(
                    child: Text(
                      metric['status'] as String,
                      style: GoogleFonts.tajawal(
                        color: _getStatusColor(metric['status'] as String),
                        fontWeight: FontWeight.bold,
                        fontSize: 12,
                      ),
                    ),
                  ),
                ),
              ),
            ],
          ),
        );
      }).toList(),
    );
  }

  Widget _buildInventoryReport() {
    final inventoryItems = [
      {'name': 'بطاريات', 'stock': 45, 'status': 'منخفض'},
      {'name': 'زيوت', 'stock': 120, 'status': 'جيد'},
      {'name': 'إطارات', 'stock': 32, 'status': 'منخفض'},
      {'name': 'فرامل', 'stock': 76, 'status': 'جيد'},
      {'name': 'محركات', 'stock': 0, 'status': 'نفذ'},
    ];

    return Column(
      children: inventoryItems.map((item) {
        return Padding(
          padding: const EdgeInsets.only(bottom: 16),
          child: Row(
            children: [
              Expanded(
                flex: 2,
                child: Text(
                  item['name'] as String,
                  style: GoogleFonts.tajawal(
                    color: Colors.grey[700],
                  ),
                ),
              ),
              Expanded(
                flex: 1,
                child: Text(
                  '${item['stock']}',
                  style: GoogleFonts.tajawal(
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ),
              Expanded(
                flex: 1,
                child: Container(
                  padding:
                      const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                  decoration: BoxDecoration(
                    color: _getInventoryStatusColor(item['status'] as String)
                        .withOpacity(0.1),
                    borderRadius: BorderRadius.circular(4),
                  ),
                  child: Center(
                    child: Text(
                      item['status'] as String,
                      style: GoogleFonts.tajawal(
                        color:
                            _getInventoryStatusColor(item['status'] as String),
                        fontWeight: FontWeight.bold,
                        fontSize: 12,
                      ),
                    ),
                  ),
                ),
              ),
            ],
          ),
        );
      }).toList(),
    );
  }

  double _getRandomHeight(double maxHeight) {
    return math.Random().nextDouble() * maxHeight + 20;
  }

  String _getMonthName(int index) {
    const months = [
      'يناير',
      'فبراير',
      'مارس',
      'أبريل',
      'مايو',
      'يونيو',
      'يوليو',
      'أغسطس',
      'سبتمبر',
      'أكتوبر',
      'نوفمبر',
      'ديسمبر'
    ];
    return months[index];
  }

  Color _getStatusColor(String status) {
    switch (status) {
      case 'ممتاز':
        return Colors.green;
      case 'جيد':
        return Colors.blue;
      case 'متوسط':
        return Colors.orange;
      case 'ضعيف':
        return Colors.red;
      default:
        return Colors.grey;
    }
  }

  Color _getInventoryStatusColor(String status) {
    switch (status) {
      case 'جيد':
        return Colors.green;
      case 'منخفض':
        return Colors.orange;
      case 'نفذ':
        return Colors.red;
      default:
        return Colors.grey;
    }
  }
}

class PieChartPainter extends CustomPainter {
  final List<Map<String, dynamic>> data;

  PieChartPainter(this.data);

  @override
  void paint(Canvas canvas, Size size) {
    final center = Offset(size.width / 2, size.height / 2);
    final radius = math.min(size.width, size.height) / 2;

    var startAngle = 0.0;

    for (var item in data) {
      final sweepAngle = (item['value'] as int) / 100 * 2 * math.pi;

      final paint = Paint()
        ..style = PaintingStyle.fill
        ..color = item['color'] as Color;

      canvas.drawArc(
        Rect.fromCircle(center: center, radius: radius),
        startAngle,
        sweepAngle,
        true,
        paint,
      );

      startAngle += sweepAngle;
    }
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) {
    return true;
  }
}
