import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:faz3a_car/core/theme/app_theme.dart';

class UsersManagement extends StatefulWidget {
  const UsersManagement({super.key});

  @override
  State<UsersManagement> createState() => _UsersManagementState();
}

class _UsersManagementState extends State<UsersManagement>
    with SingleTickerProviderStateMixin {
  late TabController _tabController;
  final TextEditingController _searchController = TextEditingController();
  String? _selectedRole;

  final List<String> _roles = ['الكل', 'مدير', 'مشرف', 'بائع', 'عميل'];

  @override
  void initState() {
    super.initState();
    _tabController = TabController(length: 3, vsync: this);
  }

  @override
  void dispose() {
    _searchController.dispose();
    _tabController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(
          'إدارة المستخدمين',
          style: GoogleFonts.tajawal(
            fontSize: 24,
            fontWeight: FontWeight.bold,
          ),
        ),
        bottom: TabBar(
          controller: _tabController,
          labelStyle: GoogleFonts.tajawal(fontWeight: FontWeight.bold),
          unselectedLabelStyle: GoogleFonts.tajawal(),
          tabs: const [
            Tab(text: 'المستخدمين'),
            Tab(text: 'الصلاحيات'),
            Tab(text: 'نشاط المستخدمين'),
          ],
        ),
        actions: [
          IconButton(
            icon: const Icon(Icons.add),
            onPressed: () {
              _showAddUserDialog();
            },
          ),
          const SizedBox(width: 16),
        ],
      ),
      body: TabBarView(
        controller: _tabController,
        children: [
          _buildUsersTab(),
          _buildRolesTab(),
          _buildUserActivityTab(),
        ],
      ),
    );
  }

  Widget _buildUsersTab() {
    return Column(
      children: [
        Padding(
          padding: const EdgeInsets.all(16),
          child: Row(
            children: [
              Expanded(
                child: TextField(
                  controller: _searchController,
                  decoration: InputDecoration(
                    hintText: 'بحث عن مستخدم...',
                    prefixIcon: const Icon(Icons.search),
                    border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(8),
                    ),
                  ),
                ),
              ),
              const SizedBox(width: 16),
              DropdownButton<String>(
                value: _selectedRole,
                hint: Text(
                  'الدور',
                  style: GoogleFonts.tajawal(),
                ),
                items: _roles.map((role) {
                  return DropdownMenuItem(
                    value: role,
                    child: Text(role),
                  );
                }).toList(),
                onChanged: (value) {
                  setState(() => _selectedRole = value);
                },
              ),
            ],
          ),
        ),
        Expanded(
          child: ListView(
            padding: const EdgeInsets.symmetric(horizontal: 16),
            children: List.generate(
              20,
              (index) => _buildUserCard(index),
            ),
          ),
        ),
      ],
    );
  }

  Widget _buildUserCard(int index) {
    final userRole = _getUserRole(index);

    return Card(
      margin: const EdgeInsets.only(bottom: 16),
      elevation: 2,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(12),
      ),
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Row(
          children: [
            CircleAvatar(
              radius: 30,
              backgroundImage: NetworkImage(
                'https://via.placeholder.com/150?text=User+${index + 1}',
              ),
            ),
            const SizedBox(width: 16),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Text(
                        'مستخدم ${index + 1}',
                        style: GoogleFonts.tajawal(
                          fontSize: 18,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                      _buildRoleBadge(userRole),
                    ],
                  ),
                  const SizedBox(height: 4),
                  Text(
                    'user${index + 1}@example.com',
                    style: GoogleFonts.tajawal(
                      color: Colors.grey[600],
                    ),
                  ),
                  const SizedBox(height: 4),
                  Text(
                    'تاريخ التسجيل: ${DateTime.now().subtract(Duration(days: index * 7)).toString().split(' ')[0]}',
                    style: GoogleFonts.tajawal(
                      color: Colors.grey[600],
                      fontSize: 12,
                    ),
                  ),
                  const SizedBox(height: 8),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.end,
                    children: [
                      TextButton.icon(
                        icon: const Icon(Icons.edit, size: 18),
                        label: Text(
                          'تعديل',
                          style: GoogleFonts.tajawal(),
                        ),
                        onPressed: () {},
                      ),
                      const SizedBox(width: 8),
                      TextButton.icon(
                        icon: const Icon(Icons.block,
                            size: 18, color: Colors.red),
                        label: Text(
                          index % 7 == 0 ? 'تفعيل' : 'حظر',
                          style: GoogleFonts.tajawal(
                            color: index % 7 == 0 ? Colors.green : Colors.red,
                          ),
                        ),
                        onPressed: () {},
                      ),
                    ],
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildRoleBadge(String role) {
    Color badgeColor;
    switch (role) {
      case 'مدير':
        badgeColor = Colors.red;
        break;
      case 'مشرف':
        badgeColor = Colors.blue;
        break;
      case 'بائع':
        badgeColor = Colors.green;
        break;
      case 'عميل':
        badgeColor = Colors.orange;
        break;
      default:
        badgeColor = Colors.grey;
    }

    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 4),
      decoration: BoxDecoration(
        color: badgeColor.withOpacity(0.1),
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: badgeColor.withOpacity(0.5)),
      ),
      child: Text(
        role,
        style: GoogleFonts.tajawal(
          color: badgeColor,
          fontWeight: FontWeight.bold,
          fontSize: 12,
        ),
      ),
    );
  }

  String _getUserRole(int index) {
    final roles = ['عميل', 'بائع', 'مشرف', 'مدير'];
    if (index < 2) return 'مدير';
    if (index < 5) return 'مشرف';
    if (index < 10) return 'بائع';
    return 'عميل';
  }

  Widget _buildRolesTab() {
    final permissions = [
      {
        'name': 'الوصول للوحة التحكم',
        'admin': true,
        'supervisor': true,
        'vendor': false,
        'customer': false
      },
      {
        'name': 'إدارة المستخدمين',
        'admin': true,
        'supervisor': true,
        'vendor': false,
        'customer': false
      },
      {
        'name': 'إدارة المنتجات',
        'admin': true,
        'supervisor': true,
        'vendor': true,
        'customer': false
      },
      {
        'name': 'إدارة الطلبات',
        'admin': true,
        'supervisor': true,
        'vendor': true,
        'customer': false
      },
      {
        'name': 'إدارة المبيعات',
        'admin': true,
        'supervisor': true,
        'vendor': false,
        'customer': false
      },
      {
        'name': 'مشاهدة التقارير',
        'admin': true,
        'supervisor': true,
        'vendor': true,
        'customer': false
      },
      {
        'name': 'إدارة الإعدادات',
        'admin': true,
        'supervisor': false,
        'vendor': false,
        'customer': false
      },
      {
        'name': 'عمليات الدفع',
        'admin': true,
        'supervisor': true,
        'vendor': false,
        'customer': false
      },
    ];

    return Padding(
      padding: const EdgeInsets.all(16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            'إدارة الصلاحيات والأدوار',
            style: GoogleFonts.tajawal(
              fontSize: 20,
              fontWeight: FontWeight.bold,
            ),
          ),
          const SizedBox(height: 16),
          Expanded(
            child: Container(
              padding: const EdgeInsets.all(16),
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.circular(12),
                boxShadow: [
                  BoxShadow(
                    color: Colors.grey.withOpacity(0.1),
                    spreadRadius: 1,
                    blurRadius: 5,
                    offset: const Offset(0, 2),
                  ),
                ],
              ),
              child: SingleChildScrollView(
                child: Table(
                  border: TableBorder.all(
                    color: Colors.grey.shade200,
                    borderRadius: BorderRadius.circular(8),
                  ),
                  defaultVerticalAlignment: TableCellVerticalAlignment.middle,
                  columnWidths: const {
                    0: FlexColumnWidth(3),
                    1: FlexColumnWidth(1),
                    2: FlexColumnWidth(1),
                    3: FlexColumnWidth(1),
                    4: FlexColumnWidth(1),
                  },
                  children: [
                    TableRow(
                      decoration: BoxDecoration(
                        color: Colors.grey.shade100,
                      ),
                      children: [
                        Padding(
                          padding: const EdgeInsets.all(12),
                          child: Text(
                            'الصلاحية',
                            style: GoogleFonts.tajawal(
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                        ),
                        Padding(
                          padding: const EdgeInsets.all(12),
                          child: Text(
                            'مدير',
                            style: GoogleFonts.tajawal(
                              fontWeight: FontWeight.bold,
                            ),
                            textAlign: TextAlign.center,
                          ),
                        ),
                        Padding(
                          padding: const EdgeInsets.all(12),
                          child: Text(
                            'مشرف',
                            style: GoogleFonts.tajawal(
                              fontWeight: FontWeight.bold,
                            ),
                            textAlign: TextAlign.center,
                          ),
                        ),
                        Padding(
                          padding: const EdgeInsets.all(12),
                          child: Text(
                            'بائع',
                            style: GoogleFonts.tajawal(
                              fontWeight: FontWeight.bold,
                            ),
                            textAlign: TextAlign.center,
                          ),
                        ),
                        Padding(
                          padding: const EdgeInsets.all(12),
                          child: Text(
                            'عميل',
                            style: GoogleFonts.tajawal(
                              fontWeight: FontWeight.bold,
                            ),
                            textAlign: TextAlign.center,
                          ),
                        ),
                      ],
                    ),
                    ...permissions
                        .map((permission) => TableRow(
                              children: [
                                Padding(
                                  padding: const EdgeInsets.all(12),
                                  child: Text(
                                    permission['name'] as String,
                                    style: GoogleFonts.tajawal(),
                                  ),
                                ),
                                Center(
                                  child: Checkbox(
                                    value: permission['admin'] as bool,
                                    onChanged: (value) {},
                                  ),
                                ),
                                Center(
                                  child: Checkbox(
                                    value: permission['supervisor'] as bool,
                                    onChanged: (value) {},
                                  ),
                                ),
                                Center(
                                  child: Checkbox(
                                    value: permission['vendor'] as bool,
                                    onChanged: (value) {},
                                  ),
                                ),
                                Center(
                                  child: Checkbox(
                                    value: permission['customer'] as bool,
                                    onChanged: (value) {},
                                  ),
                                ),
                              ],
                            ))
                        .toList(),
                  ],
                ),
              ),
            ),
          ),
          const SizedBox(height: 16),
          ElevatedButton.icon(
            icon: const Icon(Icons.save),
            label: Text(
              'حفظ التغييرات',
              style: GoogleFonts.tajawal(
                fontWeight: FontWeight.bold,
              ),
            ),
            style: ElevatedButton.styleFrom(
              padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 12),
            ),
            onPressed: () {
              ScaffoldMessenger.of(context).showSnackBar(
                const SnackBar(content: Text('تم حفظ التغييرات بنجاح')),
              );
            },
          ),
        ],
      ),
    );
  }

  Widget _buildUserActivityTab() {
    final activities = [
      {
        'user': 'مستخدم 1',
        'activity': 'تسجيل دخول',
        'date': DateTime.now().subtract(const Duration(minutes: 5))
      },
      {
        'user': 'مستخدم 3',
        'activity': 'تغيير كلمة المرور',
        'date': DateTime.now().subtract(const Duration(hours: 1))
      },
      {
        'user': 'مستخدم 2',
        'activity': 'إضافة منتج جديد',
        'date': DateTime.now().subtract(const Duration(hours: 2))
      },
      {
        'user': 'مستخدم 5',
        'activity': 'شراء منتج',
        'date': DateTime.now().subtract(const Duration(hours: 3))
      },
      {
        'user': 'مستخدم 4',
        'activity': 'تحديث البيانات الشخصية',
        'date': DateTime.now().subtract(const Duration(hours: 4))
      },
      {
        'user': 'مستخدم 6',
        'activity': 'طلب استرجاع منتج',
        'date': DateTime.now().subtract(const Duration(hours: 5))
      },
      {
        'user': 'مستخدم 1',
        'activity': 'تغيير العنوان',
        'date': DateTime.now().subtract(const Duration(hours: 6))
      },
      {
        'user': 'مستخدم 3',
        'activity': 'تسجيل خروج',
        'date': DateTime.now().subtract(const Duration(hours: 7))
      },
      {
        'user': 'مستخدم 7',
        'activity': 'تسجيل حساب جديد',
        'date': DateTime.now().subtract(const Duration(hours: 8))
      },
      {
        'user': 'مستخدم 2',
        'activity': 'تحديث منتج',
        'date': DateTime.now().subtract(const Duration(hours: 9))
      },
      {
        'user': 'مستخدم 5',
        'activity': 'إضافة تقييم',
        'date': DateTime.now().subtract(const Duration(hours: 10))
      },
      {
        'user': 'مستخدم 8',
        'activity': 'تسجيل دخول',
        'date': DateTime.now().subtract(const Duration(hours: 11))
      },
      {
        'user': 'مستخدم 9',
        'activity': 'إضافة عنوان جديد',
        'date': DateTime.now().subtract(const Duration(hours: 12))
      },
      {
        'user': 'مستخدم 10',
        'activity': 'شراء منتج',
        'date': DateTime.now().subtract(const Duration(hours: 13))
      },
    ];

    return Padding(
      padding: const EdgeInsets.all(16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            'نشاط المستخدمين',
            style: GoogleFonts.tajawal(
              fontSize: 20,
              fontWeight: FontWeight.bold,
            ),
          ),
          const SizedBox(height: 16),
          Expanded(
            child: Container(
              padding: const EdgeInsets.all(16),
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.circular(12),
                boxShadow: [
                  BoxShadow(
                    color: Colors.grey.withOpacity(0.1),
                    spreadRadius: 1,
                    blurRadius: 5,
                    offset: const Offset(0, 2),
                  ),
                ],
              ),
              child: ListView.separated(
                itemCount: activities.length,
                separatorBuilder: (context, index) => const Divider(),
                itemBuilder: (context, index) {
                  final activity = activities[index];
                  final date = activity['date'] as DateTime;

                  return ListTile(
                    title: Row(
                      children: [
                        Text(
                          activity['user'] as String,
                          style: GoogleFonts.tajawal(
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                        const SizedBox(width: 8),
                        Text(
                          activity['activity'] as String,
                          style: GoogleFonts.tajawal(),
                        ),
                      ],
                    ),
                    subtitle: Text(
                      _formatDate(date),
                      style: GoogleFonts.tajawal(
                        color: Colors.grey[600],
                        fontSize: 12,
                      ),
                    ),
                    leading: CircleAvatar(
                      backgroundColor: Colors.grey[200],
                      child: _getActivityIcon(activity['activity'] as String),
                    ),
                    trailing: IconButton(
                      icon: const Icon(Icons.info_outline),
                      onPressed: () {},
                    ),
                  );
                },
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _getActivityIcon(String activity) {
    if (activity.contains('تسجيل دخول')) {
      return const Icon(Icons.login, color: Colors.green);
    } else if (activity.contains('تسجيل خروج')) {
      return const Icon(Icons.logout, color: Colors.red);
    } else if (activity.contains('تغيير')) {
      return const Icon(Icons.edit, color: Colors.blue);
    } else if (activity.contains('إضافة')) {
      return const Icon(Icons.add_circle, color: Colors.amber);
    } else if (activity.contains('شراء')) {
      return const Icon(Icons.shopping_cart, color: Colors.purple);
    } else if (activity.contains('تحديث')) {
      return const Icon(Icons.update, color: Colors.teal);
    } else {
      return const Icon(Icons.person_outline);
    }
  }

  String _formatDate(DateTime date) {
    final now = DateTime.now();
    final difference = now.difference(date);

    if (difference.inMinutes < 60) {
      return 'منذ ${difference.inMinutes} دقيقة';
    } else if (difference.inHours < 24) {
      return 'منذ ${difference.inHours} ساعة';
    } else {
      return '${date.day}/${date.month}/${date.year} ${date.hour}:${date.minute.toString().padLeft(2, '0')}';
    }
  }

  void _showAddUserDialog() {
    final _formKey = GlobalKey<FormState>();
    final _nameController = TextEditingController();
    final _emailController = TextEditingController();
    final _passwordController = TextEditingController();
    String? _selectedUserRole;

    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: Text(
          'إضافة مستخدم جديد',
          style: GoogleFonts.tajawal(
            fontSize: 20,
            fontWeight: FontWeight.bold,
          ),
        ),
        content: Form(
          key: _formKey,
          child: SingleChildScrollView(
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                TextFormField(
                  controller: _nameController,
                  decoration: InputDecoration(
                    labelText: 'اسم المستخدم',
                    border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(8),
                    ),
                  ),
                  validator: (value) {
                    if (value == null || value.isEmpty) {
                      return 'الرجاء إدخال اسم المستخدم';
                    }
                    return null;
                  },
                ),
                const SizedBox(height: 16),
                TextFormField(
                  controller: _emailController,
                  decoration: InputDecoration(
                    labelText: 'البريد الإلكتروني',
                    border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(8),
                    ),
                  ),
                  keyboardType: TextInputType.emailAddress,
                  validator: (value) {
                    if (value == null || value.isEmpty) {
                      return 'الرجاء إدخال البريد الإلكتروني';
                    }
                    return null;
                  },
                ),
                const SizedBox(height: 16),
                TextFormField(
                  controller: _passwordController,
                  decoration: InputDecoration(
                    labelText: 'كلمة المرور',
                    border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(8),
                    ),
                  ),
                  obscureText: true,
                  validator: (value) {
                    if (value == null || value.isEmpty) {
                      return 'الرجاء إدخال كلمة المرور';
                    }
                    return null;
                  },
                ),
                const SizedBox(height: 16),
                DropdownButtonFormField<String>(
                  value: _selectedUserRole,
                  decoration: InputDecoration(
                    labelText: 'الدور',
                    border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(8),
                    ),
                  ),
                  items: _roles.sublist(1).map((role) {
                    return DropdownMenuItem(
                      value: role,
                      child: Text(role),
                    );
                  }).toList(),
                  onChanged: (value) {
                    _selectedUserRole = value;
                  },
                  validator: (value) {
                    if (value == null || value.isEmpty) {
                      return 'الرجاء اختيار الدور';
                    }
                    return null;
                  },
                ),
              ],
            ),
          ),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: Text(
              'إلغاء',
              style: GoogleFonts.tajawal(
                color: Colors.grey,
                fontWeight: FontWeight.bold,
              ),
            ),
          ),
          ElevatedButton(
            onPressed: () {
              if (_formKey.currentState!.validate()) {
                // TODO: Implement add user logic
                ScaffoldMessenger.of(context).showSnackBar(
                  const SnackBar(content: Text('تم إضافة المستخدم بنجاح')),
                );
                Navigator.pop(context);
              }
            },
            child: Text(
              'إضافة',
              style: GoogleFonts.tajawal(
                fontWeight: FontWeight.bold,
              ),
            ),
          ),
        ],
      ),
    );
  }
}
