import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:faz3a_car/core/theme/app_theme.dart';

class SettingsPage extends StatefulWidget {
  const SettingsPage({super.key});

  @override
  State<SettingsPage> createState() => _SettingsPageState();
}

class _SettingsPageState extends State<SettingsPage>
    with SingleTickerProviderStateMixin {
  late TabController _tabController;
  bool _isLoading = false;

  // Form controllers for general settings
  final _appNameController = TextEditingController(text: 'فزعة كار');
  final _contactEmailController = TextEditingController(text: 'info@faz3a.app');
  final _contactPhoneController = TextEditingController(text: '+966512345678');
  final _facebookController = TextEditingController(text: 'facebook.com/faz3a');
  final _twitterController = TextEditingController(text: 'twitter.com/faz3a');
  final _instagramController =
      TextEditingController(text: 'instagram.com/faz3a');

  // Payment settings
  bool _enableCreditCard = true;
  bool _enablePaypal = false;
  bool _enableApplePay = true;
  bool _enableGooglePay = true;
  double _taxRate = 15.0;

  // Notification settings
  bool _emailNotifications = true;
  bool _smsNotifications = true;
  bool _pushNotifications = true;
  bool _orderUpdates = true;
  bool _promotionalUpdates = false;

  @override
  void initState() {
    super.initState();
    _tabController = TabController(length: 3, vsync: this);
  }

  @override
  void dispose() {
    _tabController.dispose();
    _appNameController.dispose();
    _contactEmailController.dispose();
    _contactPhoneController.dispose();
    _facebookController.dispose();
    _twitterController.dispose();
    _instagramController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(
          'الإعدادات',
          style: GoogleFonts.tajawal(
            fontSize: 24,
            fontWeight: FontWeight.bold,
          ),
        ),
        bottom: TabBar(
          controller: _tabController,
          labelStyle: GoogleFonts.tajawal(fontWeight: FontWeight.bold),
          unselectedLabelStyle: GoogleFonts.tajawal(),
          tabs: const [
            Tab(text: 'عام'),
            Tab(text: 'المدفوعات'),
            Tab(text: 'الإشعارات'),
          ],
        ),
      ),
      body: TabBarView(
        controller: _tabController,
        children: [
          _buildGeneralSettingsTab(),
          _buildPaymentSettingsTab(),
          _buildNotificationSettingsTab(),
        ],
      ),
    );
  }

  Widget _buildGeneralSettingsTab() {
    return SingleChildScrollView(
      padding: const EdgeInsets.all(16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          _buildSectionTitle('معلومات التطبيق'),
          _buildSettingsCard(
            children: [
              _buildTextField(
                controller: _appNameController,
                label: 'اسم التطبيق',
                hint: 'أدخل اسم التطبيق',
              ),
              const SizedBox(height: 16),
              _buildTextField(
                controller: _contactEmailController,
                label: 'البريد الإلكتروني للتواصل',
                hint: 'أدخل البريد الإلكتروني',
                keyboardType: TextInputType.emailAddress,
              ),
              const SizedBox(height: 16),
              _buildTextField(
                controller: _contactPhoneController,
                label: 'رقم الهاتف للتواصل',
                hint: 'أدخل رقم الهاتف',
                keyboardType: TextInputType.phone,
              ),
            ],
          ),
          const SizedBox(height: 24),
          _buildSectionTitle('وسائل التواصل الاجتماعي'),
          _buildSettingsCard(
            children: [
              _buildTextField(
                controller: _facebookController,
                label: 'فيسبوك',
                hint: 'أدخل رابط الفيسبوك',
                prefix: Icons.facebook,
              ),
              const SizedBox(height: 16),
              _buildTextField(
                controller: _twitterController,
                label: 'تويتر',
                hint: 'أدخل رابط تويتر',
                prefix: Icons.flutter_dash,
              ),
              const SizedBox(height: 16),
              _buildTextField(
                controller: _instagramController,
                label: 'انستقرام',
                hint: 'أدخل رابط انستقرام',
                prefix: Icons.camera_alt,
              ),
            ],
          ),
          const SizedBox(height: 24),
          _buildSectionTitle('خيارات اللغة والمنطقة'),
          _buildSettingsCard(
            children: [
              _buildDropdownField(
                label: 'اللغة الافتراضية',
                value: 'العربية',
                items: const ['العربية', 'English'],
                onChanged: (value) {},
              ),
              const SizedBox(height: 16),
              _buildDropdownField(
                label: 'المنطقة الزمنية',
                value: 'الرياض (GMT+3)',
                items: const [
                  'الرياض (GMT+3)',
                  'مكة المكرمة (GMT+3)',
                  'جدة (GMT+3)'
                ],
                onChanged: (value) {},
              ),
              const SizedBox(height: 16),
              _buildDropdownField(
                label: 'العملة',
                value: 'ريال سعودي (SAR)',
                items: const [
                  'ريال سعودي (SAR)',
                  'دولار أمريكي (USD)',
                  'يورو (EUR)'
                ],
                onChanged: (value) {},
              ),
            ],
          ),
          const SizedBox(height: 24),
          _buildSaveButton(),
        ],
      ),
    );
  }

  Widget _buildPaymentSettingsTab() {
    return SingleChildScrollView(
      padding: const EdgeInsets.all(16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          _buildSectionTitle('طرق الدفع'),
          _buildSettingsCard(
            children: [
              _buildSwitchItem(
                'بطاقة الائتمان',
                _enableCreditCard,
                (value) {
                  setState(() => _enableCreditCard = value);
                },
                Icons.credit_card,
              ),
              const Divider(),
              _buildSwitchItem(
                'باي بال',
                _enablePaypal,
                (value) {
                  setState(() => _enablePaypal = value);
                },
                Icons.paypal,
              ),
              const Divider(),
              _buildSwitchItem(
                'آبل باي',
                _enableApplePay,
                (value) {
                  setState(() => _enableApplePay = value);
                },
                Icons.apple,
              ),
              const Divider(),
              _buildSwitchItem(
                'جوجل باي',
                _enableGooglePay,
                (value) {
                  setState(() => _enableGooglePay = value);
                },
                Icons.g_mobiledata,
              ),
            ],
          ),
          const SizedBox(height: 24),
          _buildSectionTitle('الضرائب'),
          _buildSettingsCard(
            children: [
              _buildSliderItem(
                'نسبة ضريبة القيمة المضافة',
                _taxRate,
                0.0,
                30.0,
                (value) {
                  setState(() => _taxRate = value);
                },
                suffix: '%',
              ),
              const SizedBox(height: 16),
              _buildSwitchItem(
                'تضمين الضريبة في السعر المعروض',
                true,
                (value) {},
                Icons.price_check,
              ),
            ],
          ),
          const SizedBox(height: 24),
          _buildSectionTitle('سياسة الاسترجاع'),
          _buildSettingsCard(
            children: [
              _buildDropdownField(
                label: 'فترة السماح للاسترجاع',
                value: '14 يوم',
                items: const ['7 أيام', '14 يوم', '30 يوم'],
                onChanged: (value) {},
              ),
              const SizedBox(height: 16),
              _buildSwitchItem(
                'السماح باسترجاع المنتج المستخدم',
                false,
                (value) {},
                Icons.restore,
              ),
              const SizedBox(height: 16),
              _buildSwitchItem(
                'خصم رسوم الشحن من المبلغ المسترجع',
                true,
                (value) {},
                Icons.local_shipping,
              ),
            ],
          ),
          const SizedBox(height: 24),
          _buildSaveButton(),
        ],
      ),
    );
  }

  Widget _buildNotificationSettingsTab() {
    return SingleChildScrollView(
      padding: const EdgeInsets.all(16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          _buildSectionTitle('إعدادات الإشعارات'),
          _buildSettingsCard(
            children: [
              _buildSwitchItem(
                'إشعارات البريد الإلكتروني',
                _emailNotifications,
                (value) {
                  setState(() => _emailNotifications = value);
                },
                Icons.email,
              ),
              const Divider(),
              _buildSwitchItem(
                'إشعارات الرسائل النصية',
                _smsNotifications,
                (value) {
                  setState(() => _smsNotifications = value);
                },
                Icons.sms,
              ),
              const Divider(),
              _buildSwitchItem(
                'إشعارات التطبيق',
                _pushNotifications,
                (value) {
                  setState(() => _pushNotifications = value);
                },
                Icons.notifications,
              ),
            ],
          ),
          const SizedBox(height: 24),
          _buildSectionTitle('أنواع الإشعارات'),
          _buildSettingsCard(
            children: [
              _buildSwitchItem(
                'تحديثات الطلبات',
                _orderUpdates,
                (value) {
                  setState(() => _orderUpdates = value);
                },
                Icons.shopping_bag,
              ),
              const Divider(),
              _buildSwitchItem(
                'العروض والتخفيضات',
                _promotionalUpdates,
                (value) {
                  setState(() => _promotionalUpdates = value);
                },
                Icons.local_offer,
              ),
              const Divider(),
              _buildSwitchItem(
                'تذكير بالسلة',
                true,
                (value) {},
                Icons.shopping_cart,
              ),
              const Divider(),
              _buildSwitchItem(
                'تحديثات النظام',
                true,
                (value) {},
                Icons.system_update,
              ),
            ],
          ),
          const SizedBox(height: 24),
          _buildSectionTitle('جدولة الإشعارات'),
          _buildSettingsCard(
            children: [
              _buildTimePickerField(
                label: 'وقت إرسال تذكير السلة',
                time: const TimeOfDay(hour: 18, minute: 0),
              ),
              const SizedBox(height: 16),
              _buildDropdownField(
                label: 'تكرار تذكير السلة',
                value: 'مرة واحدة',
                items: const ['مرة واحدة', 'يومياً', 'أسبوعياً'],
                onChanged: (value) {},
              ),
              const SizedBox(height: 16),
              _buildSwitchItem(
                'إيقاف الإشعارات أثناء ساعات النوم',
                true,
                (value) {},
                Icons.nightlight,
              ),
            ],
          ),
          const SizedBox(height: 24),
          _buildSaveButton(),
        ],
      ),
    );
  }

  Widget _buildSectionTitle(String title) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 8),
      child: Text(
        title,
        style: GoogleFonts.tajawal(
          fontSize: 18,
          fontWeight: FontWeight.bold,
        ),
      ),
    );
  }

  Widget _buildSettingsCard({required List<Widget> children}) {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(12),
        boxShadow: [
          BoxShadow(
            color: Colors.grey.withOpacity(0.1),
            spreadRadius: 1,
            blurRadius: 5,
            offset: const Offset(0, 2),
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: children,
      ),
    );
  }

  Widget _buildTextField({
    required TextEditingController controller,
    required String label,
    required String hint,
    TextInputType keyboardType = TextInputType.text,
    IconData? prefix,
  }) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          label,
          style: GoogleFonts.tajawal(
            fontWeight: FontWeight.bold,
          ),
        ),
        const SizedBox(height: 8),
        TextFormField(
          controller: controller,
          decoration: InputDecoration(
            hintText: hint,
            prefixIcon: prefix != null ? Icon(prefix) : null,
            border: OutlineInputBorder(
              borderRadius: BorderRadius.circular(8),
            ),
          ),
          keyboardType: keyboardType,
        ),
      ],
    );
  }

  Widget _buildDropdownField({
    required String label,
    required String value,
    required List<String> items,
    required Function(String?) onChanged,
  }) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          label,
          style: GoogleFonts.tajawal(
            fontWeight: FontWeight.bold,
          ),
        ),
        const SizedBox(height: 8),
        DropdownButtonFormField<String>(
          value: value,
          decoration: InputDecoration(
            border: OutlineInputBorder(
              borderRadius: BorderRadius.circular(8),
            ),
          ),
          items: items.map((item) {
            return DropdownMenuItem(
              value: item,
              child: Text(item),
            );
          }).toList(),
          onChanged: onChanged,
        ),
      ],
    );
  }

  Widget _buildTimePickerField({
    required String label,
    required TimeOfDay time,
  }) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          label,
          style: GoogleFonts.tajawal(
            fontWeight: FontWeight.bold,
          ),
        ),
        const SizedBox(height: 8),
        InkWell(
          onTap: () async {
            final TimeOfDay? picked = await showTimePicker(
              context: context,
              initialTime: time,
            );
            if (picked != null) {
              // TODO: Update time
            }
          },
          child: Container(
            padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 16),
            decoration: BoxDecoration(
              border: Border.all(color: Colors.grey.shade300),
              borderRadius: BorderRadius.circular(8),
            ),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text('${time.hour}:${time.minute.toString().padLeft(2, '0')}'),
                const Icon(Icons.access_time),
              ],
            ),
          ),
        ),
      ],
    );
  }

  Widget _buildSwitchItem(
    String title,
    bool value,
    Function(bool) onChanged,
    IconData icon,
  ) {
    return Row(
      children: [
        Icon(icon, color: AppTheme.primaryColor),
        const SizedBox(width: 12),
        Expanded(
          child: Text(
            title,
            style: GoogleFonts.tajawal(
              fontWeight: FontWeight.w500,
            ),
          ),
        ),
        Switch(
          value: value,
          onChanged: onChanged,
          activeColor: AppTheme.primaryColor,
        ),
      ],
    );
  }

  Widget _buildSliderItem(String title, double value, double min, double max,
      Function(double) onChanged,
      {String? suffix}) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Text(
              title,
              style: GoogleFonts.tajawal(
                fontWeight: FontWeight.w500,
              ),
            ),
            Text(
              '${value.toStringAsFixed(1)}${suffix ?? ''}',
              style: GoogleFonts.tajawal(
                fontWeight: FontWeight.bold,
                color: AppTheme.primaryColor,
              ),
            ),
          ],
        ),
        Slider(
          value: value,
          min: min,
          max: max,
          divisions: ((max - min) * 10).toInt(),
          label: value.toStringAsFixed(1),
          onChanged: onChanged,
          activeColor: AppTheme.primaryColor,
        ),
      ],
    );
  }

  Widget _buildSaveButton() {
    return Center(
      child: ElevatedButton(
        onPressed: _isLoading ? null : _saveSettings,
        style: ElevatedButton.styleFrom(
          minimumSize: const Size(200, 48),
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(8),
          ),
        ),
        child: _isLoading
            ? const CircularProgressIndicator(color: Colors.white)
            : Text(
                'حفظ التغييرات',
                style: GoogleFonts.tajawal(
                  fontSize: 16,
                  fontWeight: FontWeight.bold,
                ),
              ),
      ),
    );
  }

  Future<void> _saveSettings() async {
    setState(() => _isLoading = true);

    try {
      // Simulate API call
      await Future.delayed(const Duration(seconds: 2));

      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('تم حفظ الإعدادات بنجاح')),
        );
      }
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('حدث خطأ أثناء حفظ الإعدادات: $e')),
        );
      }
    } finally {
      if (mounted) {
        setState(() => _isLoading = false);
      }
    }
  }
}
