import 'package:firebase_auth/firebase_auth.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:faz3a_car/features/auth/domain/models/user_model.dart';
import 'package:faz3a_car/features/auth/domain/repositories/auth_repository.dart';
import 'package:shared_preferences/shared_preferences.dart';

class FirebaseAuthRepository implements AuthRepository {
  final FirebaseAuth _auth = FirebaseAuth.instance;
  final FirebaseFirestore _firestore = FirebaseFirestore.instance;
  static const String userCollection = 'users';
  static const String userRoleKey = 'user_role';

  @override
  User? get currentUser => _auth.currentUser;

  @override
  Stream<User?> get authStateChanges => _auth.authStateChanges();

  @override
  Future<UserCredential> signInWithEmailAndPassword({
    required String email,
    required String password,
  }) async {
    try {
      final credential = await _auth.signInWithEmailAndPassword(
        email: email,
        password: password,
      );

      // Store user role in SharedPreferences
      if (credential.user != null) {
        final userDoc = await _firestore
            .collection(userCollection)
            .doc(credential.user!.uid)
            .get();

        if (userDoc.exists) {
          final prefs = await SharedPreferences.getInstance();
          await prefs.setString(userRoleKey, userDoc.data()?['role'] ?? 'user');
        }
      }

      return credential;
    } catch (e) {
      throw _handleAuthException(e);
    }
  }

  @override
  Future<UserCredential> signUpWithEmailAndPassword({
    required String email,
    required String password,
    required String name,
    required String phone,
    String role = 'user',
  }) async {
    try {
      final credential = await _auth.createUserWithEmailAndPassword(
        email: email,
        password: password,
      );

      if (credential.user != null) {
        // Create user document in Firestore
        await _firestore
            .collection(userCollection)
            .doc(credential.user!.uid)
            .set({
          'name': name,
          'email': email,
          'phone': phone,
          'role': role,
          'createdAt': FieldValue.serverTimestamp(),
          'lastLogin': FieldValue.serverTimestamp(),
          'isActive': true,
        });

        // Update user profile
        await credential.user!.updateDisplayName(name);

        // Store user role in SharedPreferences
        final prefs = await SharedPreferences.getInstance();
        await prefs.setString(userRoleKey, role);
      }

      return credential;
    } catch (e) {
      throw _handleAuthException(e);
    }
  }

  @override
  Future<void> signOut() async {
    try {
      // Clear stored user role
      final prefs = await SharedPreferences.getInstance();
      await prefs.remove(userRoleKey);

      await _auth.signOut();
    } catch (e) {
      throw _handleAuthException(e);
    }
  }

  @override
  Future<void> resetPassword(String email) async {
    try {
      await _auth.sendPasswordResetEmail(email: email);
    } catch (e) {
      throw _handleAuthException(e);
    }
  }

  @override
  Future<void> updateProfile({
    String? name,
    String? phone,
    String? photoUrl,
  }) async {
    try {
      final user = _auth.currentUser;
      if (user != null) {
        if (name != null) {
          await user.updateDisplayName(name);
        }
        if (photoUrl != null) {
          await user.updatePhotoURL(photoUrl);
        }

        // Update Firestore document
        final updates = <String, dynamic>{
          'lastUpdated': FieldValue.serverTimestamp(),
        };
        if (name != null) updates['name'] = name;
        if (phone != null) updates['phone'] = phone;
        if (photoUrl != null) updates['photoUrl'] = photoUrl;

        await _firestore
            .collection(userCollection)
            .doc(user.uid)
            .update(updates);
      }
    } catch (e) {
      throw _handleAuthException(e);
    }
  }

  @override
  Future<void> changePassword(String newPassword) async {
    try {
      final user = _auth.currentUser;
      if (user != null) {
        await user.updatePassword(newPassword);
      }
    } catch (e) {
      throw _handleAuthException(e);
    }
  }

  @override
  Future<String> getUserRole() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      return prefs.getString(userRoleKey) ?? 'user';
    } catch (e) {
      return 'user';
    }
  }

  @override
  Future<bool> isAdmin() async {
    final role = await getUserRole();
    return role == 'admin';
  }

  @override
  Future<UserModel?> getUserData() async {
    try {
      final user = _auth.currentUser;
      if (user != null) {
        final doc =
            await _firestore.collection(userCollection).doc(user.uid).get();

        if (doc.exists) {
          return UserModel.fromMap(doc.data()!, user.uid);
        }
      }
      return null;
    } catch (e) {
      throw _handleAuthException(e);
    }
  }

  @override
  Future<void> updateLastLogin() async {
    try {
      final user = _auth.currentUser;
      if (user != null) {
        await _firestore.collection(userCollection).doc(user.uid).update({
          'lastLogin': FieldValue.serverTimestamp(),
        });
      }
    } catch (e) {
      throw _handleAuthException(e);
    }
  }

  Exception _handleAuthException(dynamic e) {
    if (e is FirebaseAuthException) {
      switch (e.code) {
        case 'user-not-found':
          return Exception('لم يتم العثور على المستخدم');
        case 'wrong-password':
          return Exception('كلمة المرور غير صحيحة');
        case 'email-already-in-use':
          return Exception('البريد الإلكتروني مستخدم بالفعل');
        case 'weak-password':
          return Exception('كلمة المرور ضعيفة');
        case 'invalid-email':
          return Exception('البريد الإلكتروني غير صالح');
        case 'operation-not-allowed':
          return Exception('العملية غير مسموح بها');
        case 'user-disabled':
          return Exception('تم تعطيل الحساب');
        case 'requires-recent-login':
          return Exception('يرجى إعادة تسجيل الدخول وإعادة المحاولة');
        default:
          return Exception('حدث خطأ غير متوقع');
      }
    }
    return Exception('حدث خطأ غير متوقع');
  }

  @override
  Future<UserModel> signInWithPhoneNumber(String phoneNumber) async {
    try {
      await _auth.verifyPhoneNumber(
        phoneNumber: phoneNumber,
        verificationCompleted: (PhoneAuthCredential credential) async {
          await _auth.signInWithCredential(credential);
        },
        verificationFailed: (FirebaseAuthException e) {
          throw Exception('Verification failed: ${e.message}');
        },
        codeSent: (String verificationId, int? resendToken) {
          // Handle code sent
        },
        codeAutoRetrievalTimeout: (String verificationId) {
          // Handle timeout
        },
      );
      return await _getUserFromFirestore(_auth.currentUser!.uid);
    } catch (e) {
      throw Exception('Failed to sign in with phone: $e');
    }
  }

  @override
  Future<UserModel> signInWithGoogle() async {
    try {
      // Implement Google Sign In
      throw UnimplementedError();
    } catch (e) {
      throw Exception('Failed to sign in with Google: $e');
    }
  }

  @override
  Future<UserModel> signInWithApple() async {
    try {
      // Implement Apple Sign In
      throw UnimplementedError();
    } catch (e) {
      throw Exception('Failed to sign in with Apple: $e');
    }
  }

  @override
  Future<UserModel> registerWithEmailAndPassword(
    String email,
    String password,
    String name,
    String phoneNumber,
  ) async {
    try {
      final UserCredential result = await _auth.createUserWithEmailAndPassword(
        email: email,
        password: password,
      );

      final user = UserModel(
        id: result.user!.uid,
        name: name,
        email: email,
        phone: phoneNumber,
        role: 'user',
        isActive: true,
        createdAt: DateTime.now(),
      );

      await _firestore.collection('users').doc(user.id).set(user.toMap());
      return user;
    } catch (e) {
      throw Exception('Failed to register: $e');
    }
  }

  @override
  Future<void> verifyPhoneNumber(String phoneNumber, String code) async {
    try {
      final PhoneAuthCredential credential = PhoneAuthProvider.credential(
        verificationId: code,
        smsCode: code,
      );
      await _auth.signInWithCredential(credential);
    } catch (e) {
      throw Exception('Failed to verify phone number: $e');
    }
  }

  @override
  Future<UserModel?> getCurrentUser() async {
    try {
      final user = _auth.currentUser;
      if (user != null) {
        return await _getUserFromFirestore(user.uid);
      }
      return null;
    } catch (e) {
      throw Exception('Failed to get current user: $e');
    }
  }

  @override
  Future<void> updateUserProfile(UserModel user) async {
    try {
      await _firestore.collection('users').doc(user.id).update(user.toMap());
    } catch (e) {
      throw Exception('Failed to update user profile: $e');
    }
  }

  @override
  Future<void> deleteAccount() async {
    try {
      final user = _auth.currentUser;
      if (user != null) {
        await _firestore.collection('users').doc(user.uid).delete();
        await user.delete();
      }
    } catch (e) {
      throw Exception('Failed to delete account: $e');
    }
  }

  Future<UserModel> _getUserFromFirestore(String uid) async {
    final doc = await _firestore.collection('users').doc(uid).get();
    if (doc.exists) {
      return UserModel.fromMap(doc.data()!, uid);
    }
    throw Exception('User not found');
  }
}
