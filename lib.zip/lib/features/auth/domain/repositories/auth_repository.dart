import 'package:firebase_auth/firebase_auth.dart';
import '../models/user_model.dart';

abstract class AuthRepository {
  Future<UserCredential> signInWithEmailAndPassword({
    required String email,
    required String password,
  });

  Future<UserCredential> signUpWithEmailAndPassword({
    required String email,
    required String password,
    required String name,
    required String phone,
    String role = 'user',
  });

  Future<void> signOut();

  Future<void> resetPassword(String email);

  Future<void> updateProfile({
    String? name,
    String? phone,
    String? photoUrl,
  });

  Future<void> changePassword(String newPassword);

  Future<String> getUserRole();

  Future<bool> isAdmin();

  Future<UserModel?> getUserData();

  Future<void> updateLastLogin();

  Stream<User?> get authStateChanges;

  User? get currentUser;
}
