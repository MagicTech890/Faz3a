import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

class HomePage extends StatelessWidget {
  const HomePage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('فزعة كار'),
        actions: [
          IconButton(
            icon: const Icon(Icons.settings),
            onPressed: () {
              // فتح صفحة الإعدادات
            },
          ),
        ],
      ),
      drawer: Drawer(
        child: ListView(
          children: [
            const DrawerHeader(
              decoration: BoxDecoration(
                color: Colors.blue,
              ),
              child: Text(
                'فزعة كار',
                style: TextStyle(
                  color: Colors.white,
                  fontSize: 24,
                ),
              ),
            ),
            ListTile(
              leading: const Icon(Icons.inventory),
              title: const Text('إدارة المخزون'),
              onTap: () {
                // التنقل إلى صفحة إدارة المخزون
              },
            ),
            ListTile(
              leading: const Icon(Icons.shopping_cart),
              title: const Text('المبيعات'),
              onTap: () {
                // التنقل إلى صفحة المبيعات
              },
            ),
            ListTile(
              leading: const Icon(Icons.people),
              title: const Text('العملاء'),
              onTap: () {
                // التنقل إلى صفحة العملاء
              },
            ),
            ListTile(
              leading: const Icon(Icons.bar_chart),
              title: const Text('التقارير'),
              onTap: () {
                // التنقل إلى صفحة التقارير
              },
            ),
          ],
        ),
      ),
      body: GridView.count(
        crossAxisCount: 2,
        padding: const EdgeInsets.all(16),
        children: [
          _buildFeatureCard(
            context,
            'المخزون',
            Icons.inventory,
            () {
              // التنقل إلى صفحة المخزون
            },
          ),
          _buildFeatureCard(
            context,
            'المبيعات',
            Icons.shopping_cart,
            () {
              // التنقل إلى صفحة المبيعات
            },
          ),
          _buildFeatureCard(
            context,
            'العملاء',
            Icons.people,
            () {
              // التنقل إلى صفحة العملاء
            },
          ),
          _buildFeatureCard(
            context,
            'التقارير',
            Icons.bar_chart,
            () {
              // التنقل إلى صفحة التقارير
            },
          ),
        ],
      ),
    );
  }

  Widget _buildFeatureCard(
    BuildContext context,
    String title,
    IconData icon,
    VoidCallback onTap,
  ) {
    return Card(
      child: InkWell(
        onTap: onTap,
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(
              icon,
              size: 48,
              color: Theme.of(context).primaryColor,
            ),
            const SizedBox(height: 8),
            Text(
              title,
              style: Theme.of(context).textTheme.titleLarge,
            ),
          ],
        ),
      ),
    );
  }
}
