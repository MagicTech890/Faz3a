import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

class AppTheme {
  // ألوان أساسية
  static const Color primaryColor = Color(0xFFFF6600);
  static const Color blackColor = Color(0xFF000000);
  static const Color whiteColor = Color(0xFFFFFFFF);

  // ألوان إضافية للوضع المشمس
  static const Color lightBackgroundColor = Color(0xFFF8F9FA);
  static const Color lightCardColor = Color(0xFFFFFFFF);
  static const Color lightTextColor = Color(0xFF333333);
  static const Color lightAccentColor = Color(0xFFFFAB40);
  static const Color lightIconColor = Color(0xFF757575);
  static const Color lightDividerColor = Color(0xFFE0E0E0);

  // ألوان إضافية للوضع الليلي
  static const Color darkBackgroundColor = Color(0xFF121212);
  static const Color darkCardColor = Color(0xFF1F1F1F);
  static const Color darkTextColor = Color(0xFFE0E0E0);
  static const Color darkAccentColor = Color(0xFFFF9E40);
  static const Color darkIconColor = Color(0xFFBDBDBD);
  static const Color darkDividerColor = Color(0xFF424242);

  // ألوان للحالات
  static const Color successColor = Color(0xFF4CAF50);
  static const Color errorColor = Color(0xFFE53935);
  static const Color warningColor = Color(0xFFFFC107);
  static const Color infoColor = Color(0xFF2196F3);

  // الوضع المشمس (الفاتح)
  static ThemeData lightTheme = ThemeData(
    useMaterial3: true,
    brightness: Brightness.light,
    primaryColor: primaryColor,
    scaffoldBackgroundColor: lightBackgroundColor,
    colorScheme: const ColorScheme.light(
      primary: primaryColor,
      secondary: lightAccentColor,
      tertiary: Color(0xFFFF8833),
      surface: lightCardColor,
      background: lightBackgroundColor,
      error: errorColor,
      onPrimary: whiteColor,
      onSecondary: blackColor,
      onSurface: lightTextColor,
      onBackground: lightTextColor,
    ),
    appBarTheme: AppBarTheme(
      backgroundColor: whiteColor,
      foregroundColor: blackColor,
      elevation: 0,
      centerTitle: true,
      shadowColor: Colors.black12,
      titleTextStyle: GoogleFonts.cairo(
        color: blackColor,
        fontSize: 20,
        fontWeight: FontWeight.bold,
      ),
    ),
    iconTheme: const IconThemeData(
      color: lightIconColor,
      size: 24,
    ),
    dividerTheme: const DividerThemeData(
      color: lightDividerColor,
      thickness: 1,
      space: 1,
    ),
    textTheme: TextTheme(
      displayLarge: GoogleFonts.cairo(
        color: blackColor,
        fontWeight: FontWeight.bold,
      ),
      displayMedium: GoogleFonts.cairo(
        color: blackColor,
        fontWeight: FontWeight.bold,
      ),
      displaySmall: GoogleFonts.cairo(
        color: blackColor,
        fontWeight: FontWeight.bold,
      ),
      headlineLarge: GoogleFonts.cairo(
        color: blackColor,
        fontWeight: FontWeight.bold,
      ),
      headlineMedium: GoogleFonts.cairo(
        color: blackColor,
        fontWeight: FontWeight.w600,
      ),
      headlineSmall: GoogleFonts.cairo(
        color: blackColor,
        fontWeight: FontWeight.w600,
      ),
      titleLarge: GoogleFonts.cairo(
        color: blackColor,
        fontWeight: FontWeight.w600,
      ),
      titleMedium: GoogleFonts.cairo(
        color: blackColor,
        fontWeight: FontWeight.w500,
      ),
      titleSmall: GoogleFonts.cairo(
        color: blackColor,
        fontWeight: FontWeight.w500,
      ),
      bodyLarge: GoogleFonts.tajawal(color: blackColor),
      bodyMedium: GoogleFonts.tajawal(color: blackColor),
      bodySmall: GoogleFonts.tajawal(color: blackColor),
      labelLarge: GoogleFonts.tajawal(
        color: blackColor,
        fontWeight: FontWeight.w500,
      ),
      labelMedium: GoogleFonts.tajawal(color: blackColor),
      labelSmall: GoogleFonts.tajawal(color: blackColor),
    ),
    elevatedButtonTheme: ElevatedButtonThemeData(
      style: ElevatedButton.styleFrom(
        backgroundColor: primaryColor,
        foregroundColor: whiteColor,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(8),
        ),
        padding: const EdgeInsets.symmetric(
          horizontal: 24,
          vertical: 12,
        ),
        elevation: 2,
      ),
    ),
    outlinedButtonTheme: OutlinedButtonThemeData(
      style: OutlinedButton.styleFrom(
        foregroundColor: primaryColor,
        side: const BorderSide(color: primaryColor),
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(8),
        ),
        padding: const EdgeInsets.symmetric(
          horizontal: 24,
          vertical: 12,
        ),
      ),
    ),
    cardTheme: CardTheme(
      color: lightCardColor,
      elevation: 2,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(12),
      ),
      shadowColor: Colors.black.withOpacity(0.1),
    ),
    inputDecorationTheme: InputDecorationTheme(
      filled: true,
      fillColor: whiteColor,
      border: OutlineInputBorder(
        borderRadius: BorderRadius.circular(8),
        borderSide: const BorderSide(color: primaryColor),
      ),
      enabledBorder: OutlineInputBorder(
        borderRadius: BorderRadius.circular(8),
        borderSide: BorderSide(color: primaryColor.withOpacity(0.5)),
      ),
      focusedBorder: OutlineInputBorder(
        borderRadius: BorderRadius.circular(8),
        borderSide: const BorderSide(color: primaryColor, width: 2),
      ),
      errorBorder: OutlineInputBorder(
        borderRadius: BorderRadius.circular(8),
        borderSide: const BorderSide(color: errorColor),
      ),
      labelStyle: GoogleFonts.tajawal(color: blackColor.withOpacity(0.7)),
      hintStyle: GoogleFonts.tajawal(color: blackColor.withOpacity(0.5)),
    ),
    bottomNavigationBarTheme: const BottomNavigationBarThemeData(
      backgroundColor: whiteColor,
      selectedItemColor: primaryColor,
      unselectedItemColor: lightIconColor,
      type: BottomNavigationBarType.fixed,
      elevation: 8,
    ),
  );

  // الوضع الليلي (الداكن)
  static ThemeData darkTheme = ThemeData(
    useMaterial3: true,
    brightness: Brightness.dark,
    primaryColor: primaryColor,
    scaffoldBackgroundColor: darkBackgroundColor,
    colorScheme: const ColorScheme.dark(
      primary: primaryColor,
      secondary: darkAccentColor,
      tertiary: Color(0xFFFF8833),
      surface: darkCardColor,
      background: darkBackgroundColor,
      error: errorColor,
      onPrimary: whiteColor,
      onSecondary: whiteColor,
      onSurface: darkTextColor,
      onBackground: darkTextColor,
    ),
    appBarTheme: AppBarTheme(
      backgroundColor: Colors.black,
      foregroundColor: whiteColor,
      elevation: 0,
      centerTitle: true,
      titleTextStyle: GoogleFonts.cairo(
        color: whiteColor,
        fontSize: 20,
        fontWeight: FontWeight.bold,
      ),
    ),
    iconTheme: const IconThemeData(
      color: darkIconColor,
      size: 24,
    ),
    dividerTheme: const DividerThemeData(
      color: darkDividerColor,
      thickness: 1,
      space: 1,
    ),
    textTheme: TextTheme(
      displayLarge: GoogleFonts.cairo(
        color: whiteColor,
        fontWeight: FontWeight.bold,
      ),
      displayMedium: GoogleFonts.cairo(
        color: whiteColor,
        fontWeight: FontWeight.bold,
      ),
      displaySmall: GoogleFonts.cairo(
        color: whiteColor,
        fontWeight: FontWeight.bold,
      ),
      headlineLarge: GoogleFonts.cairo(
        color: whiteColor,
        fontWeight: FontWeight.bold,
      ),
      headlineMedium: GoogleFonts.cairo(
        color: whiteColor,
        fontWeight: FontWeight.w600,
      ),
      headlineSmall: GoogleFonts.cairo(
        color: whiteColor,
        fontWeight: FontWeight.w600,
      ),
      titleLarge: GoogleFonts.cairo(
        color: whiteColor,
        fontWeight: FontWeight.w600,
      ),
      titleMedium: GoogleFonts.cairo(
        color: whiteColor,
        fontWeight: FontWeight.w500,
      ),
      titleSmall: GoogleFonts.cairo(
        color: whiteColor,
        fontWeight: FontWeight.w500,
      ),
      bodyLarge: GoogleFonts.tajawal(color: whiteColor),
      bodyMedium: GoogleFonts.tajawal(color: whiteColor),
      bodySmall: GoogleFonts.tajawal(color: whiteColor),
      labelLarge: GoogleFonts.tajawal(
        color: whiteColor,
        fontWeight: FontWeight.w500,
      ),
      labelMedium: GoogleFonts.tajawal(color: whiteColor),
      labelSmall: GoogleFonts.tajawal(color: whiteColor),
    ),
    elevatedButtonTheme: ElevatedButtonThemeData(
      style: ElevatedButton.styleFrom(
        backgroundColor: primaryColor,
        foregroundColor: whiteColor,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(8),
        ),
        padding: const EdgeInsets.symmetric(
          horizontal: 24,
          vertical: 12,
        ),
        elevation: 3,
      ),
    ),
    outlinedButtonTheme: OutlinedButtonThemeData(
      style: OutlinedButton.styleFrom(
        foregroundColor: primaryColor,
        side: const BorderSide(color: primaryColor),
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(8),
        ),
        padding: const EdgeInsets.symmetric(
          horizontal: 24,
          vertical: 12,
        ),
      ),
    ),
    cardTheme: CardTheme(
      color: darkCardColor,
      elevation: 3,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(12),
      ),
      shadowColor: Colors.black.withOpacity(0.3),
    ),
    inputDecorationTheme: InputDecorationTheme(
      filled: true,
      fillColor: darkCardColor,
      border: OutlineInputBorder(
        borderRadius: BorderRadius.circular(8),
        borderSide: const BorderSide(color: primaryColor),
      ),
      enabledBorder: OutlineInputBorder(
        borderRadius: BorderRadius.circular(8),
        borderSide: BorderSide(color: primaryColor.withOpacity(0.5)),
      ),
      focusedBorder: OutlineInputBorder(
        borderRadius: BorderRadius.circular(8),
        borderSide: const BorderSide(color: primaryColor, width: 2),
      ),
      errorBorder: OutlineInputBorder(
        borderRadius: BorderRadius.circular(8),
        borderSide: const BorderSide(color: errorColor),
      ),
      labelStyle: GoogleFonts.tajawal(color: whiteColor.withOpacity(0.7)),
      hintStyle: GoogleFonts.tajawal(color: whiteColor.withOpacity(0.5)),
    ),
    bottomNavigationBarTheme: const BottomNavigationBarThemeData(
      backgroundColor: Colors.black,
      selectedItemColor: primaryColor,
      unselectedItemColor: darkIconColor,
      type: BottomNavigationBarType.fixed,
      elevation: 8,
    ),
  );
}
