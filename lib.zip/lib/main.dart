import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:flutter_localizations/flutter_localizations.dart';
import 'package:faz3a_car/features/admin/presentation/pages/admin_dashboard.dart';
import 'package:faz3a_car/features/odoo/providers/odoo_provider.dart';
import 'package:faz3a_car/core/theme/app_theme.dart';
import 'package:faz3a_car/features/auth/presentation/pages/login_screen.dart';
import 'package:faz3a_car/features/splash/presentation/pages/splash_screen.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:shared_preferences/shared_preferences.dart';

// Importaciones adicionales
import 'package:faz3a_car/features/customer/presentation/pages/catalog_page.dart';
import 'package:faz3a_car/features/customer/presentation/pages/product_details_page.dart';
import 'package:faz3a_car/features/customer/presentation/pages/cart_page.dart';
import 'package:faz3a_car/features/customer/presentation/pages/checkout_page.dart';
import 'package:faz3a_car/features/customer/presentation/pages/profile_page.dart';
import 'package:faz3a_car/features/customer/presentation/pages/orders_history_page.dart';
import 'package:faz3a_car/features/auth/presentation/pages/register_screen.dart';
import 'package:faz3a_car/features/auth/presentation/pages/forgot_password_screen.dart';
import 'package:faz3a_car/features/customer/presentation/pages/car_categories_page.dart';
import 'package:faz3a_car/features/customer/presentation/pages/category_parts_page.dart';
import 'package:faz3a_car/features/customer/presentation/pages/workshops_page.dart';
import 'package:faz3a_car/features/customer/presentation/pages/chinese_cars_page.dart';
import 'package:faz3a_car/features/customer/presentation/pages/payment_methods_page.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  // Initialize theme from saved preferences
  final themeProvider = ThemeProvider();
  await themeProvider.initialize();
  // Firebase initialization removed temporarily to run the app
  runApp(
    MultiProvider(
      providers: [
        ChangeNotifierProvider(create: (_) => OdooProvider()),
        ChangeNotifierProvider.value(value: themeProvider),
        ChangeNotifierProvider(create: (_) => AuthProvider()),
        ChangeNotifierProvider(create: (_) => CartProvider()),
        ChangeNotifierProvider(create: (_) => ProductsProvider()),
        ChangeNotifierProvider(create: (_) => OrdersProvider()),
      ],
      child: const MyApp(),
    ),
  );
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return Consumer<ThemeProvider>(builder: (context, themeProvider, child) {
      return MaterialApp(
        title: 'فزعة كار',
        theme:
            themeProvider.isDarkMode ? AppTheme.darkTheme : AppTheme.lightTheme,
        localizationsDelegates: const [
          GlobalMaterialLocalizations.delegate,
          GlobalWidgetsLocalizations.delegate,
          GlobalCupertinoLocalizations.delegate,
        ],
        supportedLocales: const [
          Locale('ar', ''),
        ],
        locale: const Locale('ar', ''),
        debugShowCheckedModeBanner: false,
        initialRoute: '/',
        routes: {
          '/': (context) => const SplashScreen(),
          '/login': (context) => const LoginScreen(),
          '/register': (context) => const RegisterScreen(),
          '/forgot-password': (context) => const ForgotPasswordScreen(),
          '/admin': (context) => const AdminDashboard(),
          '/home': (context) => const CustomerHome(),
          '/catalog': (context) => const CatalogPage(),
          '/product-details': (context) => const ProductDetailsPage(),
          '/cart': (context) => const CartPage(),
          '/checkout': (context) => const CheckoutPage(),
          '/profile': (context) => const ProfilePage(),
          '/order-history': (context) => const OrdersHistoryPage(),
          '/car-categories': (context) => const CarCategoriesPage(),
          '/category-parts': (context) => const CategoryPartsPage(),
          '/workshops': (context) => const WorkshopsPage(),
          '/chinese-cars': (context) => const ChineseCarsPage(),
          '/payment-methods': (context) => const PaymentMethodsPage(),
        },
      );
    });
  }
}

class ThemeProvider extends ChangeNotifier {
  bool _isDarkMode = false;
  static const String _themePreferenceKey = 'isDarkMode';

  bool get isDarkMode => _isDarkMode;

  // Initialize theme from shared preferences
  Future<void> initialize() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      _isDarkMode = prefs.getBool(_themePreferenceKey) ?? false;
    } catch (e) {
      if (kDebugMode) {
        print('Error loading theme preference: $e');
      }
    }
  }

  // Toggle theme and save to shared preferences
  Future<void> toggleTheme() async {
    _isDarkMode = !_isDarkMode;
    notifyListeners();

    try {
      final prefs = await SharedPreferences.getInstance();
      await prefs.setBool(_themePreferenceKey, _isDarkMode);
    } catch (e) {
      if (kDebugMode) {
        print('Error saving theme preference: $e');
      }
    }
  }
}

class AuthProvider extends ChangeNotifier {
  bool _isLoggedIn = false;
  String _userType = ''; // admin, vendor, customer
  String _userName = '';
  String _userEmail = '';
  String _userId = '';
  String _userPhone = '';

  bool get isLoggedIn => _isLoggedIn;
  String get userType => _userType;
  String get userName => _userName;
  String get userEmail => _userEmail;
  String get userId => _userId;
  String get userPhone => _userPhone;

  Future<bool> login(String email, String password) async {
    try {
      // التحقق من بيانات المسؤول
      if (email.toLowerCase() == 'admin@faz3a.com' && password == 'admin123') {
        _isLoggedIn = true;
        _userType = 'admin';
        _userName = 'مدير النظام';
        _userEmail = email.toLowerCase();
        _userId = 'admin-123';
        notifyListeners();
        return true;
      } else if (email.isNotEmpty && password.length >= 6) {
        _isLoggedIn = true;
        _userType = 'customer';
        _userName = 'عميل';
        _userEmail = email.toLowerCase();
        _userId = 'customer-${DateTime.now().millisecondsSinceEpoch}';
        notifyListeners();
        return true;
      }
      return false;
    } catch (e) {
      if (kDebugMode) {
        print('خطأ في تسجيل الدخول: $e');
      }
      return false;
    }
  }

  Future<bool> phoneLogin(String phone) async {
    try {
      if (phone.length >= 10) {
        _isLoggedIn = true;
        _userType = 'customer';
        _userName = 'عميل';
        _userPhone = phone;
        _userId = 'customer-${DateTime.now().millisecondsSinceEpoch}';
        notifyListeners();
        return true;
      }
      return false;
    } catch (e) {
      if (kDebugMode) {
        print('Phone login error: $e');
      }
      return false;
    }
  }

  Future<bool> register(
      String name, String email, String password, String phone) async {
    // In a real app, we would register the user in a database
    // For demo purposes, we'll accept any registration
    _isLoggedIn = true;
    _userType = 'customer';
    _userName = name;
    _userEmail = email;
    _userId = 'customer-${DateTime.now().millisecondsSinceEpoch}';
    notifyListeners();
    return true;
  }

  Future<bool> resetPassword(String email) async {
    // In a real app, we would send a reset password email
    // For demo purposes, we'll just return true
    return true;
  }

  void logout() {
    _isLoggedIn = false;
    _userType = '';
    _userName = '';
    _userEmail = '';
    _userId = '';
    notifyListeners();
  }
}

// Proveedor para el carrito de compras
class CartProvider extends ChangeNotifier {
  List<CartItem> _items = [];

  List<CartItem> get items => _items;

  double get total =>
      _items.fold(0, (sum, item) => sum + (item.price * item.quantity));

  int get count => _items.fold(0, (sum, item) => sum + item.quantity);

  void addItem(CartItem item) {
    final existingItemIndex =
        _items.indexWhere((i) => i.productId == item.productId);

    if (existingItemIndex >= 0) {
      _items[existingItemIndex].quantity += item.quantity;
    } else {
      _items.add(item);
    }

    notifyListeners();
  }

  void removeItem(String productId) {
    _items.removeWhere((item) => item.productId == productId);
    notifyListeners();
  }

  void updateQuantity(String productId, int quantity) {
    final index = _items.indexWhere((item) => item.productId == productId);

    if (index >= 0) {
      _items[index].quantity = quantity;
      notifyListeners();
    }
  }

  void clear() {
    _items = [];
    notifyListeners();
  }
}

// Modelo para los items del carrito
class CartItem {
  final String productId;
  final String name;
  final double price;
  int quantity;
  final String imageUrl;

  CartItem({
    required this.productId,
    required this.name,
    required this.price,
    required this.quantity,
    required this.imageUrl,
  });
}

// Proveedor para los productos
class ProductsProvider extends ChangeNotifier {
  List<Product> _products = [];
  bool _isLoading = false;

  List<Product> get products => _products;
  bool get isLoading => _isLoading;

  // En una aplicación real, los productos se cargarían desde un backend
  Future<void> loadProducts() async {
    _isLoading = true;
    notifyListeners();

    // Simular carga de datos
    await Future.delayed(const Duration(milliseconds: 800));

    // Datos de ejemplo
    _products = List.generate(
      20,
      (index) => Product(
        id: 'product-$index',
        name: 'قطعة غيار ${index + 1}',
        description:
            'وصف تفصيلي للقطعة رقم ${index + 1}، تتضمن المواصفات والخصائص.',
        price: (index + 1) * 50.0,
        imageUrl:
            'https://via.placeholder.com/200x200?text=Product+${index + 1}',
        category: _getRandomCategory(),
        stock: (index + 1) * 5,
        rating: (index % 5) + 1,
      ),
    );

    _isLoading = false;
    notifyListeners();
  }

  Product? getProductById(String id) {
    try {
      return _products.firstWhere((product) => product.id == id);
    } catch (e) {
      return null;
    }
  }

  List<Product> getProductsByCategory(String category) {
    if (category == 'الكل') {
      return _products;
    }
    return _products.where((product) => product.category == category).toList();
  }

  List<String> get categories {
    final categories =
        _products.map((product) => product.category).toSet().toList();
    return ['الكل', ...categories];
  }

  static String _getRandomCategory() {
    final categories = ['بطاريات', 'زيوت', 'إطارات', 'فرامل', 'محركات', 'أخرى'];
    return categories[
        DateTime.now().millisecondsSinceEpoch % categories.length];
  }
}

// Modelo para los productos
class Product {
  final String id;
  final String name;
  final String description;
  final double price;
  final String imageUrl;
  final String category;
  final int stock;
  final int rating;

  Product({
    required this.id,
    required this.name,
    required this.description,
    required this.price,
    required this.imageUrl,
    required this.category,
    required this.stock,
    required this.rating,
  });
}

// Proveedor para los pedidos
class OrdersProvider extends ChangeNotifier {
  List<Order> _orders = [];
  bool _isLoading = false;

  List<Order> get orders => _orders;
  bool get isLoading => _isLoading;

  Future<void> loadOrders(String userId) async {
    _isLoading = true;
    notifyListeners();

    // Simular carga de datos
    await Future.delayed(const Duration(milliseconds: 800));

    // Datos de ejemplo
    _orders = List.generate(
      5,
      (index) => Order(
        id: 'order-$index',
        userId: userId,
        items: List.generate(
          (index % 3) + 1,
          (itemIndex) => OrderItem(
            productId: 'product-${itemIndex + 1}',
            name: 'منتج ${itemIndex + 1}',
            price: (itemIndex + 1) * 50.0,
            quantity: (itemIndex % 3) + 1,
          ),
        ),
        total: ((index % 3) + 1) * 150.0,
        status: _getRandomOrderStatus(),
        date: DateTime.now().subtract(Duration(days: index * 3)),
      ),
    );

    _isLoading = false;
    notifyListeners();
  }

  Future<bool> placeOrder(
      String userId, List<CartItem> items, double total) async {
    _isLoading = true;
    notifyListeners();

    // Simular envío de pedido
    await Future.delayed(const Duration(milliseconds: 1200));

    // Crear el nuevo pedido
    final newOrder = Order(
      id: 'order-${DateTime.now().millisecondsSinceEpoch}',
      userId: userId,
      items: items
          .map((item) => OrderItem(
                productId: item.productId,
                name: item.name,
                price: item.price,
                quantity: item.quantity,
              ))
          .toList(),
      total: total,
      status: 'جديد',
      date: DateTime.now(),
    );

    // Agregar el pedido a la lista
    _orders.insert(0, newOrder);

    _isLoading = false;
    notifyListeners();

    return true;
  }

  static String _getRandomOrderStatus() {
    final statuses = ['جديد', 'قيد المعالجة', 'تم التسليم', 'ملغي'];
    return statuses[DateTime.now().millisecondsSinceEpoch % statuses.length];
  }
}

// Modelo para los pedidos
class Order {
  final String id;
  final String userId;
  final List<OrderItem> items;
  final double total;
  final String status;
  final DateTime date;

  Order({
    required this.id,
    required this.userId,
    required this.items,
    required this.total,
    required this.status,
    required this.date,
  });
}

// Modelo para los items de un pedido
class OrderItem {
  final String productId;
  final String name;
  final double price;
  final int quantity;

  OrderItem({
    required this.productId,
    required this.name,
    required this.price,
    required this.quantity,
  });
}

// صفحة العملاء
class CustomerHome extends StatefulWidget {
  const CustomerHome({super.key});

  @override
  State<CustomerHome> createState() => _CustomerHomeState();
}

class _CustomerHomeState extends State<CustomerHome> {
  int _currentIndex = 0;

  @override
  void initState() {
    super.initState();
    // Cargar los productos cuando se inicia la página
    WidgetsBinding.instance.addPostFrameCallback((_) {
      Provider.of<ProductsProvider>(context, listen: false).loadProducts();
      final userId = Provider.of<AuthProvider>(context, listen: false).userId;
      Provider.of<OrdersProvider>(context, listen: false).loadOrders(userId);
    });
  }

  @override
  Widget build(BuildContext context) {
    final authProvider = Provider.of<AuthProvider>(context);
    final cartProvider = Provider.of<CartProvider>(context);

    // Lista de páginas para el bottom navigation
    final List<Widget> pages = [
      const CatalogPage(),
      const CartPage(),
      const OrdersHistoryPage(),
      const ProfilePage(),
    ];

    return Scaffold(
      appBar: AppBar(
        title: Text(
          _getAppBarTitle(),
          style: GoogleFonts.tajawal(
            fontSize: 20,
            fontWeight: FontWeight.bold,
          ),
        ),
        actions: [
          if (_currentIndex !=
              1) // No mostrar el botón del carrito en la página del carrito
            Stack(
              alignment: Alignment.center,
              children: [
                IconButton(
                  icon: const Icon(Icons.shopping_cart),
                  onPressed: () {
                    setState(() {
                      _currentIndex = 1; // Ir a la página del carrito
                    });
                  },
                ),
                if (cartProvider.count > 0)
                  Positioned(
                    top: 5,
                    right: 5,
                    child: Container(
                      padding: const EdgeInsets.all(4),
                      decoration: BoxDecoration(
                        color: AppTheme.primaryColor,
                        shape: BoxShape.circle,
                      ),
                      child: Text(
                        '${cartProvider.count}',
                        style: const TextStyle(
                          color: Colors.white,
                          fontSize: 10,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                    ),
                  ),
              ],
            ),
          IconButton(
            icon: const Icon(Icons.logout),
            onPressed: () {
              authProvider.logout();
              Navigator.of(context).pushReplacementNamed('/login');
            },
            tooltip: 'تسجيل الخروج',
          ),
        ],
      ),
      body: pages[_currentIndex],
      bottomNavigationBar: BottomNavigationBar(
        currentIndex: _currentIndex,
        onTap: (index) {
          setState(() {
            _currentIndex = index;
          });
        },
        type: BottomNavigationBarType.fixed,
        selectedItemColor: AppTheme.primaryColor,
        items: const [
          BottomNavigationBarItem(
            icon: Icon(Icons.home),
            label: 'الرئيسية',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.shopping_cart),
            label: 'السلة',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.receipt_long),
            label: 'طلباتي',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.person),
            label: 'حسابي',
          ),
        ],
      ),
    );
  }

  String _getAppBarTitle() {
    switch (_currentIndex) {
      case 0:
        return 'فزعة كار - المنتجات';
      case 1:
        return 'سلة المشتريات';
      case 2:
        return 'طلباتي السابقة';
      case 3:
        return 'الملف الشخصي';
      default:
        return 'فزعة كار';
    }
  }
}
